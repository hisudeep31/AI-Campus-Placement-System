# Technical Documentation (V3)

This document explains how the system is put together and why. For setup see `README.md`; for every endpoint see `docs/openapi.yaml` (paste it into https://editor.swagger.io to browse).

## 1. Architecture

```mermaid
flowchart LR
    subgraph Browser
        C[React + Vite + Tailwind<br/>student / company / officer / admin dashboards]
    end
    subgraph API["Node.js / Express API (port 5000)"]
        MW[helmet · CORS · rate limit · JWT auth · RBAC · zod validation]
        CT[Controllers: auth, student, company, officer,<br/>resume, drive, alumni, roadmap, verification, analytics]
        UT[Utils: pipeline state machine · readiness · tokens ·<br/>mailer · ics · logger · pagination]
    end
    subgraph AI["Python FastAPI AI service (port 8000)"]
        P[Resume parser + OCR fallback]
        S[Weighted ATS scorer]
        R[Hybrid recommender<br/>semantic + TF-IDF fallback]
        I[Interview generator + answer evaluator]
        G[Roadmap generator · resume improver]
    end
    DB[(PostgreSQL 16<br/>35 tables)]
    FS[(uploads/ volume<br/>private, never served statically)]
    SMTP[[SMTP — optional<br/>dry-run if unset]]

    C -- "/api (JWT)" --> MW --> CT --> UT
    CT --> DB
    CT -- "axios" --> AI
    CT --> FS
    UT --> SMTP
```

Design choices worth defending in a viva:

- **Two services, not one.** The Python service owns everything ML/NLP so its heavy dependencies never touch the API; the API degrades gracefully when it is down (resume still uploads, score is skipped).
- **Transparent AI over black boxes.** Every score (ATS, interview answer, readiness) is a documented formula whose inputs are shown to the user ("evidence"). No score is presented as a hiring decision.
- **The server is the source of truth.** Eligibility (CGPA, deadline), application-status transitions, approval, and file access are enforced in the API, never trusted from the UI.

## 2. Security model

```mermaid
sequenceDiagram
    participant B as Browser
    participant A as API
    participant D as PostgreSQL
    B->>A: POST /auth/login
    A->>D: check password, is_approved, is_active
    A->>D: INSERT refresh_tokens (sha256 hash only)
    A-->>B: access JWT (1h, carries tv) + refresh token
    B->>A: request + Bearer access token
    A->>D: users.is_active and token_version == tv ?
    A-->>B: 200 (or 401/403 immediately if revoked/disabled)
    B->>A: 401 expired → POST /auth/refresh
    A->>D: revoke used refresh token, insert new one (rotation)
    A-->>B: new access + refresh tokens
```

| Control | Where |
|---|---|
| Self-registration limited to student/company; approval enforced at login | `auth.controller.js` |
| Short-lived access token + rotating, hashed refresh token | `utils/tokens.js` |
| Instant revocation (disable user / bump `token_version`) | `middleware/auth.js` |
| Role-based access (`authorize(...)`) and row-level ownership checks via SQL joins | routes + controllers |
| Resumes and company documents are private; access only via authenticated download endpoints | `resume.controller.js`, `verification.controller.js` |
| Helmet headers, rate limit on login/register, zod request validation | `app.js`, `auth.routes.js`, `utils/validation.js` |
| Structured logging with Winston; audit trail in `activity_logs` | `utils/logger.js`, `utils/activityLog.js` |
| Default admin credentials trigger a loud boot warning | `utils/seedAdmin.js` |

## 3. Application pipeline (server-enforced)

```mermaid
stateDiagram-v2
    [*] --> applied
    applied --> under_review
    applied --> shortlisted
    under_review --> shortlisted
    shortlisted --> interview_scheduled
    interview_scheduled --> interview_scheduled: reschedule
    interview_scheduled --> interview_completed: feedback submitted
    interview_completed --> selected
    applied --> on_hold
    under_review --> on_hold
    shortlisted --> on_hold
    interview_scheduled --> on_hold
    interview_completed --> on_hold
    on_hold --> under_review
    on_hold --> shortlisted
    applied --> rejected
    under_review --> rejected
    shortlisted --> rejected
    interview_scheduled --> rejected
    interview_completed --> rejected
    on_hold --> rejected
    selected --> [*]
    rejected --> [*]
```

`interview_scheduled` and `interview_completed` can only be reached through their dedicated actions (schedule interview / submit feedback), so the history in `applications.status_history` always matches real events. Rules live in `server/src/utils/pipeline.js` and are unit-tested.

## 4. AI components and how they score

| Component | Method | Notes |
|---|---|---|
| Resume parser | pdfplumber + regex/section heuristics → name, education, experience, projects, certifications, skills | OCR (pytesseract) only if the PDF has almost no text **and** OCR is installed; otherwise skipped, never faked |
| ATS score (job-specific) | Skills 35 · Experience 20 · Education 15 · Projects 15 · Structure 10 · Certifications 5 | Each dimension returns its score, max, and an evidence sentence |
| Resume improver | Rewording of the student's own lines + prompts to add a real number | Never invents experience, metrics, or skills |
| Job recommender | `0.5·skill overlap + 0.3·semantic + 0.2·TF-IDF` (semantic needs `sentence-transformers` and model weights; without them: `0.65·overlap + 0.35·TF-IDF`) | Response states which `method` ran; shows matched/missing skills and reasons; ineligible jobs are filtered out first |
| Interview questions | Curated bank tagged by category and difficulty (LLM-generated if `ANTHROPIC_API_KEY` is set) | Each question carries the concepts a good answer should cover |
| Answer evaluator | Technical 40 · Conceptual 25 · Explanation 20 · Completeness 15 | Rule-based; reports low confidence when no reference concepts exist |
| Learning roadmap | Missing skills, mandatory first, foundations before frameworks | Curated official links; unknown skills get a labelled search link, never an invented URL |
| Placement readiness | CGPA 25 · Skills 20 · Resume 20 · Projects 10 · Mock interviews 15 · Profile extras 10 | Stored with `method='rule_based'`. `train_readiness_model.py` is a scaffold that refuses to train on too little real data |

## 5. Backend module map

| Area | Files |
|---|---|
| Auth & sessions | `auth.controller.js`, `utils/tokens.js`, `middleware/auth.js` |
| Student | `student.controller.js` (profile, resume, recommendations, skill gap, mock interviews, readiness, calendar) |
| Company | `company.controller.js` (jobs, applicants, status, interviews, feedback, analytics), `verification.controller.js` |
| Officer / admin | `officer.controller.js`, `analytics.controller.js`, `admin.controller.js` |
| Resumes | `resume.controller.js` |
| Drives, alumni, roadmaps | `routes/drive.routes.js`, `routes/alumni.routes.js`, `routes/roadmap.routes.js` |
| Cross-cutting | `utils/pipeline.js`, `readiness.js`, `notify.js`, `mailer.js`, `ics.js`, `pagination.js`, `validation.js`, `logger.js` |

## 6. Testing

| Suite | Command | Covers |
|---|---|---|
| AI service (pytest, 23 tests) | `cd ai-service && python -m pytest tests -q` | ATS scoring, parser helpers, improver, evaluator, generator, recommender fallback, roadmap |
| API logic (Node built-in runner, 11 tests) | `cd server && npm test` | State machine, readiness formula, ICS output, pagination |

These are unit tests of pure logic. There is no end-to-end HTTP test suite yet; the SQL used by the API was additionally checked by loading `schema.sql` into PostgreSQL 16 and preparing/executing every static query against it (see README "How this was verified").

## 7. Honest limitations and deferred work

| Item | Status | Why |
|---|---|---|
| Real ML placement prediction | Deferred (rule-based readiness shipped) | Needs real historical outcomes; invented training data would produce a meaningless model |
| Coding assessment with code execution | Not built | Running untrusted code needs a sandbox (containers/gVisor, resource limits); it must never run in the API process |
| Real email delivery | Wired, needs your SMTP credentials | Without them mail is logged as a dry run and is not sent |
| Semantic recommendations | Optional | Needs `sentence-transformers` and downloadable model weights; falls back to TF-IDF automatically |
| OCR for scanned resumes | Optional | Needs `pytesseract` + the `tesseract-ocr` binary (included in the AI Dockerfile) |
| Word (.doc/.docx) resume parsing | Not supported | Parser reads PDFs; other uploads are stored but unscored |
| End-to-end / browser tests | Not included | Unit-level tests only |
| Academic report, DFDs, UML as files | Not included | Diagrams for architecture, security, pipeline and ERD are above; the report itself is yours to write |

## 8. Database schema (ER diagram)

Generated from the live schema (35 tables, 45 foreign-key relationships).

```mermaid
erDiagram
    users ||--o{ activity_logs : has
    users ||--o{ alumni : has
    jobs ||--o{ applications : has
    students ||--o{ applications : has
    students ||--o{ certificates : has
    users ||--o{ companies : has
    companies ||--o{ company_documents : has
    drive_registrations ||--o{ drive_attendance : has
    companies ||--o{ drive_companies : has
    jobs ||--o{ drive_companies : has
    placement_drives ||--o{ drive_companies : has
    placement_drives ||--o{ drive_registrations : has
    students ||--o{ drive_registrations : has
    students ||--o{ education : has
    students ||--o{ experiences : has
    mock_interviews ||--o{ interview_answers : has
    interview_answers ||--o{ interview_evaluations : has
    interviews ||--o{ interview_feedback : has
    users ||--o{ interview_feedback : has
    applications ||--o{ interviews : has
    jobs ||--o{ job_skills : has
    skills ||--o{ job_skills : has
    companies ||--o{ jobs : has
    learning_roadmaps ||--o{ learning_progress : has
    jobs ||--o{ learning_roadmaps : has
    students ||--o{ learning_roadmaps : has
    jobs ||--o{ mock_interviews : has
    students ||--o{ mock_interviews : has
    users ||--o{ notification_preferences : has
    users ||--o{ notifications : has
    users ||--o{ placement_drives : has
    jobs ||--o{ prediction_results : has
    students ||--o{ prediction_results : has
    students ||--o{ projects : has
    users ||--o{ refresh_tokens : has
    users ||--o{ reports : has
    jobs ||--o{ resume_ats_history : has
    resumes ||--o{ resume_ats_history : has
    students ||--o{ resume_ats_history : has
    resumes ||--o{ resume_parsed_data : has
    students ||--o{ resumes : has
    skills ||--o{ student_skills : has
    students ||--o{ student_skills : has
    users ||--o{ students : has
    roles ||--o{ users : has
    activity_logs {
        uuid id PK
        uuid user_id FK
        string action
        jsonb metadata
        timestamp created_at
    }
    alumni {
        uuid id PK
        string full_name
        int graduation_year
        string department
        string current_organization
        string job_role
        string industry
        bool mentorship_available
        string contact_email
        text linkedin_url
        uuid added_by FK
        timestamp created_at
    }
    applications {
        uuid id PK
        uuid student_id FK
        uuid job_id FK
        string status
        decimal match_score
        decimal final_salary
        jsonb status_history
        timestamp applied_at
    }
    certificates {
        uuid id PK
        uuid student_id FK
        string title
        string issuer
        date issue_date
        text credential_url
    }
    companies {
        uuid id PK
        uuid user_id FK
        string company_name
        string website
        string industry
        text logo_url
        text description
        string verification_status
        timestamp verified_at
        uuid verified_by FK
        timestamp created_at
    }
    company_documents {
        uuid id PK
        uuid company_id FK
        string doc_type
        text file_url
        timestamp uploaded_at
    }
    drive_attendance {
        uuid id PK
        uuid registration_id FK
        bool attended
        string outcome
        timestamp marked_at
    }
    drive_companies {
        uuid drive_id PK
        uuid company_id PK
        uuid job_id FK
    }
    drive_registrations {
        uuid id PK
        uuid drive_id FK
        uuid student_id FK
        timestamp registered_at
    }
    education {
        uuid id PK
        uuid student_id FK
        string institution
        string degree
        string field_of_study
        int start_year
        int end_year
        string grade
    }
    experiences {
        uuid id PK
        uuid student_id FK
        string company_name
        string role_title
        date start_date
        date end_date
        text description
    }
    interview_answers {
        uuid id PK
        uuid mock_interview_id FK
        int question_index
        text question_text
        text answer_text
        timestamp created_at
    }
    interview_evaluations {
        uuid id PK
        uuid answer_id FK
        decimal technical_score
        decimal conceptual_score
        decimal explanation_score
        decimal completeness_score
        decimal overall_score
        jsonb feedback
        timestamp created_at
    }
    interview_feedback {
        uuid id PK
        uuid interview_id FK
        decimal technical_rating
        decimal problem_solving_rating
        decimal communication_rating
        decimal score
        text strengths
        text weaknesses
        text comments
        string recommendation
        uuid submitted_by FK
        timestamp created_at
    }
    interviews {
        uuid id PK
        uuid application_id FK
        timestamp scheduled_at
        string mode
        string interviewer_name
        string status
        timestamp created_at
    }
    job_skills {
        uuid job_id PK
        int skill_id PK
        bool is_mandatory
    }
    jobs {
        uuid id PK
        uuid company_id FK
        string title
        text description
        string location
        string job_type
        decimal min_cgpa
        decimal salary_min
        decimal salary_max
        date application_deadline
        string status
        timestamp created_at
    }
    learning_progress {
        uuid id PK
        uuid roadmap_id FK
        int step_index
        bool completed
        timestamp completed_at
    }
    learning_roadmaps {
        uuid id PK
        uuid student_id FK
        uuid job_id FK
        jsonb steps
        timestamp created_at
    }
    mock_interviews {
        uuid id PK
        uuid student_id FK
        uuid job_id FK
        string difficulty
        jsonb questions
        decimal self_score
        timestamp created_at
    }
    notification_preferences {
        uuid user_id PK
        bool email_enabled
        bool in_app_enabled
    }
    notifications {
        uuid id PK
        uuid user_id FK
        string title
        text message
        bool is_read
        timestamp created_at
    }
    placement_drives {
        uuid id PK
        string title
        text description
        date drive_date
        date registration_deadline
        decimal min_cgpa
        array eligible_departments
        uuid created_by FK
        timestamp created_at
    }
    prediction_results {
        uuid id PK
        uuid student_id FK
        uuid job_id FK
        decimal readiness_score
        jsonb factors
        string method
        timestamp created_at
    }
    projects {
        uuid id PK
        uuid student_id FK
        string title
        text description
        string tech_stack
        text project_url
    }
    refresh_tokens {
        uuid id PK
        uuid user_id FK
        string token_hash
        timestamp expires_at
        timestamp revoked_at
        timestamp created_at
    }
    reports {
        uuid id PK
        uuid generated_by FK
        string report_type
        jsonb filters
        text file_url
        timestamp created_at
    }
    resume_ats_history {
        uuid id PK
        uuid resume_id FK
        uuid student_id FK
        uuid job_id FK
        decimal overall_score
        jsonb breakdown
        array missing_keywords
        timestamp scored_at
    }
    resume_parsed_data {
        uuid id PK
        uuid resume_id FK
        string full_name
        array emails
        array phones
        jsonb education
        jsonb experience
        jsonb projects
        jsonb certifications
        timestamp extracted_at
    }
    resumes {
        uuid id PK
        uuid student_id FK
        text file_url
        text file_path
        string label
        bool is_default
        jsonb parsed_json
        decimal ats_score
        array missing_keywords
        timestamp uploaded_at
    }
    roles {
        int id PK
        string name
    }
    skills {
        int id PK
        string name
    }
    student_skills {
        uuid student_id PK
        int skill_id PK
        string proficiency
    }
    students {
        uuid id PK
        uuid user_id FK
        string full_name
        string phone
        string department
        decimal cgpa
        int graduation_year
        text photo_url
        text resume_url
        decimal ats_score
        timestamp created_at
    }
    users {
        uuid id PK
        string email
        string password_hash
        int role_id FK
        bool is_approved
        bool is_active
        int token_version
        timestamp last_login
        timestamp password_changed_at
        timestamp created_at
        timestamp updated_at
    }
```
