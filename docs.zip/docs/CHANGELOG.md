# Changelog

## v3 — summary
See the main README ("What's new in v3") for the V3 changes. Below is the v2 review-pass history, kept verbatim.

## v2 — review pass

## 1. Four roles, what each can do

**Student** — register (pending approval) → log in → complete profile →
list skills → upload resume for AI-scored ATS feedback (generic or
job-specific) → check skill gap against any open job → get AI job
recommendations → apply to jobs (CGPA/deadline/status enforced) → track
applications → view scheduled interviews → generate AI mock-interview
questions (generic or job-specific).

**Company** — register (pending approval) → log in → edit company profile
→ post jobs with required skills, CGPA cutoff, deadline, salary range →
open/close postings → view ranked applicants with resumes → change
application status (notifies the student) → schedule interviews
(ownership-checked; notifies the student).

**Placement Officer** — log in (pre-approved) → approve/revoke student and
company accounts → view placement analytics (overall %, department-wise
chart, average ATS score, top recruiters) → export any report as CSV.

**Admin** — log in (pre-approved, seeded on first boot) → create
officer/admin accounts (the *only* way to create them — public
registration rejects these roles) → enable/disable or approve/revoke any
user → view the full activity log.

---

## 2. What this review pass fixed

### Critical security fixes
1. **Registration role bypass.** The public `/auth/register` endpoint used
   to accept `role: "admin"` or `role: "placement_officer"` even though the
   UI only exposed student/company — anyone scripting a direct API call
   could create themselves an admin account. **Fixed**: the endpoint now
   hard-rejects any role outside `["student", "company"]`. Officer/admin
   accounts can only be created via `POST /api/admin/users` by an existing
   admin (see the Admin dashboard's "Create Account" tab).
2. **Approval was cosmetic.** Placement officers could toggle a student or
   company's `is_approved` flag, but the login endpoint never checked it —
   an unapproved account could log in anyway. **Fixed**: `login()` now
   returns 403 with a clear message if `is_approved` is false. Registration
   no longer auto-logs-in the new account for this reason — it returns a
   "pending approval" message instead, and the Register page shows that.
3. **Interview scheduling had no ownership check.** Any authenticated
   company could POST to `/api/companies/applications/:id/interview` with
   *any* application ID and schedule an interview on it, regardless of
   whether that application belonged to one of their own job postings.
   **Fixed**: the endpoint now joins `applications → jobs → companies` and
   verifies `companies.user_id = req.user.id` before inserting anything.

### High-priority logic fixes
4. **Job application had no eligibility checks.** A student could apply to
   a closed job, a job past its deadline, or a job below their CGPA cutoff
   — the fields existed on the job posting but nothing enforced them.
   **Fixed**: `POST /api/jobs/:id/apply` now checks `status === 'open'`,
   `application_deadline` against the current date, and the student's
   CGPA against `min_cgpa`, in addition to the existing duplicate check.
5. **ATS scoring was always generic.** Every resume was scored against the
   same fixed keyword list (`Python, JavaScript, React, ...`) regardless of
   which job the student cared about. **Fixed**: resume upload now accepts
   an optional `job_id`; when given, the AI service scores against *that
   job's* required skills instead. A new `GET /me/resume/match/:jobId`
   endpoint re-scores an already-uploaded resume against a different job
   without re-uploading the PDF (the AI service's `/resume/parse` now
   returns the extracted full text so it can be persisted and reused).
6. **Mock interview ignored the job.** The frontend could send a `job_id`
   but the backend only ever used the student's own listed skills.
   **Fixed**: when a `job_id` is given, the backend unions the student's
   skills with that job's required skills before asking the AI service for
   questions — so a student prepping for a Docker-heavy role gets Docker
   questions even if they haven't listed Docker as a skill yet.

### Missing features added
7. **Skill-Gap tab** on the student dashboard — pick any open job, see
   exactly which required skills you have vs. are missing, with a match %.
8. **Profile editing UI** for both students (name/phone/department/CGPA/
   graduation year) and companies (name/website/industry/description) —
   the backend endpoints existed before but had no form to drive them.
   Added `GET /api/companies/me` (only `PUT` existed previously).
9. **Interview scheduling UI** — companies get an inline form on each
   applicant to pick a date/time, mode, and interviewer; students get a new
   **Interviews** tab showing everything scheduled across their applications.
10. **Top recruiters table + CSV report export** — the analytics query
    existed but was never rendered; it's now a table on the officer
    dashboard. A new `GET /api/officer/reports/export?type=...` endpoint
    (overview / department / students / companies / top-recruiters) streams
    a CSV, with an "Export CSV" button next to each relevant chart/table.
11. **In-app notifications** — a bell icon in the navbar (polls every 20s)
    shows unread count and a dropdown list. Notifications now fire on:
    application status change, interview scheduled, account approved/
    revoked, and admin account updates.
12. **Admin activity log viewer** — `GET /api/admin/logs` existed with
    nothing writing to the table. Now `logActivity()` is called on login,
    registration, approvals, job posting, application status changes,
    interview scheduling, report exports, and admin user management, and
    there's an "Activity Log" tab on the Admin dashboard to read it.
13. **Resume upload history** — students can now see every past resume
    upload with its score and a link to view the PDF, not just the latest.
14. **Search/filter polish** — job browsing now filters by location and
    job type in addition to text search; the officer's student list has a
    department dropdown (backed by a new `GET /api/officer/departments`).
15. **Default admin credentials** now print a loud, impossible-to-miss
    console warning on first boot if you haven't set `ADMIN_EMAIL` /
    `ADMIN_PASSWORD` in `server/.env` — change them immediately.

### Still intentionally out of scope (unchanged from the MVP)
- Email/SMS delivery for notifications (in-app only, by design — add a
  mailer in `utils/notify.js` if you want this)
- Cloud file storage (resumes save to local disk in dev; swap
  `server/src/utils/upload.js` for Cloudinary/S3 for a real deployment)
- Video interviews, coding assessments, alumni features — these were
  always "future enhancements" in the original brief, not MVP scope
- Automated test suite (still nothing here — see Section 6 if you want to add one)

---

