// V3: server-enforced application state machine. Previously a company could
// PATCH any status onto any application (e.g. jump "applied" -> "offered",
// or resurrect a "rejected" one). Every status change now goes through
// assertTransition(), so the rules live in one place and the UI is merely
// a convenience over them.
export const STATES = [
  "applied", "under_review", "shortlisted", "interview_scheduled",
  "interview_completed", "selected", "rejected", "on_hold",
];

export const TRANSITIONS = {
  applied: ["under_review", "shortlisted", "rejected", "on_hold"],
  under_review: ["shortlisted", "rejected", "on_hold"],
  shortlisted: ["interview_scheduled", "rejected", "on_hold"],
  interview_scheduled: ["interview_scheduled", "interview_completed", "rejected", "on_hold"],
  interview_completed: ["selected", "rejected", "on_hold"],
  on_hold: ["under_review", "shortlisted", "rejected"],
  selected: [],   // terminal
  rejected: [],   // terminal
};

export const allowedNext = (from) => TRANSITIONS[from] || [];

export const canTransition = (from, to) => allowedNext(from).includes(to);

// Returns an error message if the move is illegal, otherwise null.
export const assertTransition = (from, to) => {
  if (!STATES.includes(to)) return `Invalid status "${to}"`;
  if (from === to && to !== "interview_scheduled") return `Application is already "${to}"`;
  if (!canTransition(from, to)) {
    const next = allowedNext(from);
    return next.length
      ? `Cannot move an application from "${from}" to "${to}". Allowed: ${next.join(", ")}`
      : `"${from}" is a final status and cannot be changed`;
  }
  return null;
};

// SQL fragment that applies a status change and appends to status_history.
// statusParam / byParam are the 1-based positional parameter numbers.
export const statusUpdateSql = (statusParam, byParam) => `
  status = $${statusParam}::varchar,
  status_history = COALESCE(status_history, '[]'::jsonb) ||
    jsonb_build_array(jsonb_build_object('status', $${statusParam}::text, 'at', now(), 'by', $${byParam}::text))`;
