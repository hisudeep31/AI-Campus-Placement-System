import { query } from "../config/db.js";

/**
 * Records an entry in activity_logs for admin/audit visibility.
 * Fire-and-forget — logging failures must never break the parent request.
 */
export const logActivity = async (userId, action, metadata = {}) => {
  try {
    await query(
      `INSERT INTO activity_logs (user_id, action, metadata) VALUES ($1, $2, $3)`,
      [userId || null, action, JSON.stringify(metadata)]
    );
  } catch (err) {
    console.warn("Failed to write activity log:", err.message);
  }
};
