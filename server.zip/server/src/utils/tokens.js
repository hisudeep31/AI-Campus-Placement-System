import jwt from "jsonwebtoken";
import crypto from "crypto";
import { query } from "../config/db.js";

const ACCESS_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "1h";
const REFRESH_EXPIRES_DAYS = parseInt(process.env.REFRESH_TOKEN_EXPIRES_DAYS || "7", 10);

// Short-lived access token. `tv` (token_version) is embedded so the
// authenticate middleware can detect a revoked session without the token
// itself being tracked server-side — only its version number is checked.
export const signAccessToken = (user) =>
  jwt.sign(
    { id: user.id, role: user.role_name, email: user.email, tv: user.token_version || 0 },
    process.env.JWT_SECRET,
    { expiresIn: ACCESS_EXPIRES_IN }
  );

const hashToken = (token) => crypto.createHash("sha256").update(token).digest("hex");

// Issues a new opaque refresh token, stores only its hash (never the raw
// value — matches the "store hashed" requirement from the blueprint), and
// returns the raw token to hand to the client.
export const issueRefreshToken = async (userId) => {
  const raw = crypto.randomBytes(48).toString("hex");
  const expiresAt = new Date(Date.now() + REFRESH_EXPIRES_DAYS * 24 * 60 * 60 * 1000);
  await query(
    `INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES ($1, $2, $3)`,
    [userId, hashToken(raw), expiresAt]
  );
  return raw;
};

// Rotation: looks up the refresh token by hash, verifies it's unrevoked
// and unexpired, revokes it, and issues a brand new one. Rotating on
// every use means a stolen-and-replayed refresh token can only be used
// once before the legitimate client's next refresh fails and both get
// invalidated together — a cheap detection signal for token theft.
export const rotateRefreshToken = async (rawToken) => {
  const tokenHash = hashToken(rawToken);
  const result = await query(
    `SELECT id, user_id, expires_at, revoked_at FROM refresh_tokens WHERE token_hash = $1`,
    [tokenHash]
  );
  if (!result.rows.length) return null;
  const row = result.rows[0];
  if (row.revoked_at || new Date(row.expires_at) < new Date()) return null;

  await query(`UPDATE refresh_tokens SET revoked_at = now() WHERE id = $1`, [row.id]);
  const newRaw = await issueRefreshToken(row.user_id);
  return { userId: row.user_id, refreshToken: newRaw };
};

export const revokeRefreshToken = async (rawToken) => {
  await query(`UPDATE refresh_tokens SET revoked_at = now() WHERE token_hash = $1`, [hashToken(rawToken)]);
};

// Revokes every refresh token for a user AND bumps token_version, which
// instantly invalidates every access token already issued to them too —
// used for "log out everywhere" and forced-disable by an admin.
export const revokeAllSessions = async (userId) => {
  await query(`UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL`, [userId]);
  await query(`UPDATE users SET token_version = token_version + 1 WHERE id = $1`, [userId]);
};
