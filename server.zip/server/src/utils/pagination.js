// V3: simple, additive pagination helper for list endpoints that could
// grow large (jobs, user lists, student/company lists). Kept backward
// compatible on purpose: the response body is still a plain array (so
// existing frontend code that does `res.data.map(...)` keeps working
// unchanged), and pagination metadata rides along in response headers
// instead of wrapping the payload in an envelope.
export const getPagination = (req, { defaultLimit = 50, maxLimit = 200 } = {}) => {
  let page = parseInt(req.query.page, 10);
  let limit = parseInt(req.query.limit, 10);
  if (!Number.isFinite(page) || page < 1) page = 1;
  if (!Number.isFinite(limit) || limit < 1) limit = defaultLimit;
  if (limit > maxLimit) limit = maxLimit;
  const offset = (page - 1) * limit;
  return { page, limit, offset };
};

// Sets X-Total-Count / X-Page / X-Page-Limit headers and returns the page
// of rows. Call this right before res.json(rows).
export const sendPaginated = (res, rows, { page, limit, total }) => {
  res.set("X-Total-Count", String(total));
  res.set("X-Page", String(page));
  res.set("X-Page-Limit", String(limit));
  res.set("Access-Control-Expose-Headers", "X-Total-Count, X-Page, X-Page-Limit");
  return res.json(rows);
};
