import { z } from "zod";

// V3: centralized request-body schemas using zod, instead of ad-hoc
// `if (!field) return 400` checks scattered across controllers. A single
// `validate(schema)` middleware below handles all of them the same way.

export const registerSchema = z.object({
  email: z.string().email("A valid email is required"),
  // Password strength: 8+ chars, at least one letter and one number.
  // (The V3 blueprint asks for "password-strength validation" — this is
  // deliberately not maximalist (no mandatory special characters) since
  // overly strict rules just push students toward "Password1!" patterns.)
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Za-z]/, "Password must contain at least one letter")
    .regex(/[0-9]/, "Password must contain at least one number"),
  role: z.enum(["student", "company"]),
  full_name: z.string().min(1).optional(),
  company_name: z.string().min(1).optional(),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export const createJobSchema = z.object({
  title: z.string().min(1),
  description: z.string().min(1),
  location: z.string().optional().nullable(),
  job_type: z.enum(["full_time", "internship", "contract"]).optional(),
  min_cgpa: z.coerce.number().min(0).max(10).optional().nullable(),
  salary_min: z.coerce.number().nonnegative().optional().nullable(),
  salary_max: z.coerce.number().nonnegative().optional().nullable(),
  application_deadline: z.string().optional().nullable(),
  skills: z
    .array(z.object({ name: z.string().min(1), is_mandatory: z.boolean().optional() }))
    .optional(),
});

export const scheduleInterviewSchema = z.object({
  scheduled_at: z.string().min(1, "scheduled_at is required"),
  mode: z.enum(["online", "offline"]).optional(),
  interviewer_name: z.string().optional().nullable(),
});

export const createDriveSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional().nullable(),
  drive_date: z.string().optional().nullable(),
  registration_deadline: z.string().optional().nullable(),
  min_cgpa: z.coerce.number().min(0).max(10).optional().nullable(),
  eligible_departments: z.array(z.string()).optional(),
});

export const interviewFeedbackSchema = z.object({
  technical_rating: z.coerce.number().min(1).max(10),
  problem_solving_rating: z.coerce.number().min(1).max(10),
  communication_rating: z.coerce.number().min(1).max(10),
  strengths: z.string().optional().nullable(),
  weaknesses: z.string().optional().nullable(),
  comments: z.string().optional().nullable(),
  recommendation: z.enum(["selected", "rejected", "on_hold"]),
});

export const answerSubmissionSchema = z.object({
  question_index: z.coerce.number().int().min(0),
  question_text: z.string().min(1),
  answer_text: z.string().min(1, "Answer cannot be empty"),
});

// Middleware factory: validates req.body against `schema`, replaces
// req.body with the parsed/coerced result (so e.g. "7.5" becomes 7.5),
// or responds 400 with the first validation issue.
export const validate = (schema) => (req, res, next) => {
  const result = schema.safeParse(req.body);
  if (!result.success) {
    const firstIssue = result.error.issues[0];
    return res.status(400).json({
      error: firstIssue ? `${firstIssue.path.join(".")}: ${firstIssue.message}` : "Invalid request body",
    });
  }
  req.body = result.data;
  next();
};
