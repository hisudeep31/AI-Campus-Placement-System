import winston from "winston";

// Centralized logger (V3). Replaces scattered console.log/console.warn in
// new code; existing console calls elsewhere still work fine side-by-side
// since they're separate output streams, but new code should use this.
export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || "info",
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.printf(({ level, message, timestamp, ...meta }) => {
          const extra = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : "";
          return `${timestamp} [${level}] ${message}${extra}`;
        })
      ),
    }),
  ],
});
