import { logger } from "./logger.js";

// Email delivery with an honest dry-run fallback. If SMTP isn't configured
// (or nodemailer isn't installed), the email is NOT sent — it is logged as
// a dry run so nobody believes mail went out when it didn't. Callers get
// { sent: boolean, dryRun: boolean } back.
const smtpConfigured = () => Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASSWORD);

let transporter = null;
const getTransporter = async () => {
  if (transporter) return transporter;
  const nodemailer = (await import("nodemailer")).default; // lazy: optional at boot
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || "587", 10),
    secure: process.env.SMTP_PORT === "465",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD },
  });
  return transporter;
};

export const sendEmail = async ({ to, subject, text, html, attachments }) => {
  if (!to) return { sent: false, dryRun: false };
  if (!smtpConfigured()) {
    logger.info("[email dry-run] SMTP not configured; email not sent", { to, subject });
    return { sent: false, dryRun: true };
  }
  try {
    const t = await getTransporter();
    await t.sendMail({ from: process.env.SMTP_FROM || process.env.SMTP_USER, to, subject, text, html, attachments });
    return { sent: true, dryRun: false };
  } catch (err) {
    logger.warn("Email send failed", { to, subject, error: err.message });
    return { sent: false, dryRun: false };
  }
};
