import { query } from "../config/db.js";
import { sendEmail } from "./mailer.js";
import { logger } from "./logger.js";

/**
 * Notifies a user: in-app notification and/or email, honouring their
 * notification_preferences (both default ON when no row exists).
 * Fire-and-forget by design — a notification failure must never fail the
 * parent request, so callers just do `notify(userId, "title", "message")`.
 */
export const notify = async (userId, title, message) => {
  if (!userId) return;
  try {
    const prefRes = await query(
      `SELECT u.email, COALESCE(p.email_enabled, TRUE) AS email_enabled, COALESCE(p.in_app_enabled, TRUE) AS in_app_enabled
       FROM users u LEFT JOIN notification_preferences p ON p.user_id = u.id WHERE u.id = $1`,
      [userId]
    );
    if (!prefRes.rows.length) return;
    const { email, email_enabled, in_app_enabled } = prefRes.rows[0];

    if (in_app_enabled) {
      await query(`INSERT INTO notifications (user_id, title, message) VALUES ($1, $2, $3)`, [userId, title, message]);
    }
    if (email_enabled) {
      // Not awaited: SMTP latency must not slow the request that triggered this.
      sendEmail({ to: email, subject: `[Campus Placement] ${title}`, text: message }).catch(() => {});
    }
  } catch (err) {
    logger.warn("Failed to create notification", { userId, error: err.message });
  }
};
