import bcrypt from "bcryptjs";
import { query } from "../config/db.js";

const DEFAULT_EMAIL = "admin@example.com";
const DEFAULT_PASSWORD = "Admin123!";
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || DEFAULT_EMAIL;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || DEFAULT_PASSWORD;

export const ensureAdminAccount = async () => {
  const existing = await query("SELECT id FROM users WHERE email=$1", [ADMIN_EMAIL]);
  if (existing.rows.length) {
    return;
  }

  let roleRes = await query("SELECT id FROM roles WHERE name=$1", ["admin"]);
  let roleId;
  if (roleRes.rows.length) {
    roleId = roleRes.rows[0].id;
  } else {
    const inserted = await query("INSERT INTO roles (name) VALUES ($1) RETURNING id", ["admin"]);
    roleId = inserted.rows[0].id;
  }

  const passwordHash = await bcrypt.hash(ADMIN_PASSWORD, 10);
  await query(
    `INSERT INTO users (email, password_hash, role_id, is_approved, is_active)
     VALUES ($1, $2, $3, true, true)`,
    [ADMIN_EMAIL, passwordHash, roleId]
  );

  // Warn whenever the DEFAULT credentials are in play — whether because
  // .env doesn't set them at all, or because .env (or docker-compose.yml)
  // sets them to the same known default values. Either way, anyone who
  // has read this source file can log in as admin.
  const usingDefaults = ADMIN_EMAIL === DEFAULT_EMAIL && ADMIN_PASSWORD === DEFAULT_PASSWORD;
  if (usingDefaults) {
    console.warn(
      "\n" +
      "⚠️  SECURITY WARNING ⚠️\n" +
      "ADMIN_EMAIL / ADMIN_PASSWORD are at their default values.\n" +
      `A default admin account was created: ${ADMIN_EMAIL} / ${ADMIN_PASSWORD}\n` +
      "This is public in the project's source/README. Log in and change this\n" +
      "password immediately, or set real ADMIN_EMAIL / ADMIN_PASSWORD values\n" +
      "in server/.env (or docker-compose.yml) BEFORE any real deployment.\n"
    );
  } else {
    console.log(`Created admin user: ${ADMIN_EMAIL}`);
  }
};
