// Placement readiness score — a TRANSPARENT, rule-based formula (0-100).
// This is deliberately not a trained model: with no real historical
// placement outcomes there is nothing honest to train on. Every point maps
// to a visible profile fact, and the weights are shown to the student.
// Scores are guidance for the student/officer, never a hiring decision.
//
//   CGPA            25   linear 5.0 -> 0, 9.0+ -> full
//   Skills          20   10+ skills -> full
//   Resume (ATS)    20   ATS score / 100
//   Projects        10   3+ projects -> full
//   Mock interviews 15   average mock score / 100 (0 if none attempted)
//   Profile extras  10   certificates (up to 2) + experience entry
export const READINESS_WEIGHTS = {
  cgpa: 25, skills: 20, resume: 20, projects: 10, mock_interviews: 15, profile_extras: 10,
};

const clamp01 = (x) => Math.max(0, Math.min(1, x));

export const computeReadiness = ({ cgpa, skillCount, atsScore, projectCount, mockAvg, certificateCount, experienceCount }) => {
  const ratios = {
    cgpa: cgpa == null ? 0 : clamp01((Number(cgpa) - 5) / 4),
    skills: clamp01((skillCount || 0) / 10),
    resume: clamp01((Number(atsScore) || 0) / 100),
    projects: clamp01((projectCount || 0) / 3),
    mock_interviews: clamp01((Number(mockAvg) || 0) / 100),
    profile_extras: clamp01(((Math.min(certificateCount || 0, 2) / 2) * 0.6) + ((experienceCount || 0) > 0 ? 0.4 : 0)),
  };

  const factors = Object.entries(READINESS_WEIGHTS).map(([key, max]) => ({
    key,
    score: Math.round(ratios[key] * max * 10) / 10,
    max,
  }));
  const readiness = Math.round(factors.reduce((a, f) => a + f.score, 0) * 10) / 10;

  const tips = {
    cgpa: "Raise or keep your CGPA healthy — many drives have a cutoff.",
    skills: "Add more in-demand skills to your profile (aim for 10).",
    resume: "Upload a resume and improve its ATS score using the suggestions.",
    projects: "Add 2–3 projects that show what you can build.",
    mock_interviews: "Practice with AI mock interviews to build confidence.",
    profile_extras: "Add certificates and any internship/experience.",
  };
  // Biggest gaps (most points left on the table) become the suggestions.
  const suggestions = [...factors]
    .map((f) => ({ ...f, gap: f.max - f.score }))
    .filter((f) => f.gap >= f.max * 0.3)
    .sort((a, b) => b.gap - a.gap)
    .slice(0, 3)
    .map((f) => tips[f.key]);

  const band = readiness >= 70 ? "strong" : readiness >= 45 ? "developing" : "needs_attention";
  return { readiness, band, factors, suggestions, method: "rule_based" };
};

// Loads the inputs for one student (by students.id) and computes readiness.
export const readinessForStudent = async (query, studentId) => {
  const r = await query(
    `SELECT s.cgpa, s.ats_score,
            (SELECT count(*) FROM student_skills WHERE student_id = s.id)::int AS skill_count,
            (SELECT count(*) FROM projects WHERE student_id = s.id)::int AS project_count,
            (SELECT count(*) FROM certificates WHERE student_id = s.id)::int AS certificate_count,
            (SELECT count(*) FROM experiences WHERE student_id = s.id)::int AS experience_count,
            (SELECT avg(e.overall_score) FROM mock_interviews m
               JOIN interview_answers a ON a.mock_interview_id = m.id
               JOIN interview_evaluations e ON e.answer_id = a.id
             WHERE m.student_id = s.id) AS mock_avg
     FROM students s WHERE s.id = $1`,
    [studentId]
  );
  if (!r.rows.length) return null;
  const x = r.rows[0];
  return computeReadiness({
    cgpa: x.cgpa, skillCount: x.skill_count, atsScore: x.ats_score, projectCount: x.project_count,
    mockAvg: x.mock_avg, certificateCount: x.certificate_count, experienceCount: x.experience_count,
  });
};
