// Centralized API response shape (V3). New endpoints use these helpers so
// every response from the API has the same envelope: { success, data } or
// { success: false, message, ...extra }. Pre-existing V1/V2 endpoints were
// left returning bare JSON for backward compatibility with the existing
// frontend — mixing the two is safe since the frontend reads specific
// fields, not the envelope shape, but new frontend code added in V3 reads
// the new envelope where it talks to new endpoints.
export const ok = (res, data, status = 200) => res.status(status).json({ success: true, data });

export const fail = (res, status, message, extra = {}) =>
  res.status(status).json({ success: false, message, ...extra });
