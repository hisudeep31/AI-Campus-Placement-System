import { logger } from "../utils/logger.js";

export const notFound = (req, res) => {
  res.status(404).json({ error: `Route not found: ${req.originalUrl}` });
};

export const errorHandler = (err, req, res, next) => {
  logger.error(err.message || "Unhandled error", {
    status: err.status || 500,
    path: req.originalUrl,
    method: req.method,
    stack: err.stack,
  });
  res.status(err.status || 500).json({
    error: err.message || "Internal server error",
  });
};
