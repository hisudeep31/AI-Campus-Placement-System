import jwt from "jsonwebtoken";
import { query } from "../config/db.js";

// V3: previously this only verified the JWT signature and trusted its
// payload blindly for the token's entire 7-day lifetime — so disabling a
// user's account, or an admin revoking their approval, had no effect
// until the token happened to expire. We now re-check the user's current
// is_active flag and token_version against the database on every request.
// token_version is bumped (see utils/tokens.js) on password change or an
// explicit "log out everywhere", which immediately invalidates every
// previously-issued access token for that user.
//
// This costs one extra indexed lookup per request — acceptable at this
// app's scale, and the right tradeoff for a system that gates logins on
// manual approval in the first place.
export const authenticate = async (req, res, next) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith("Bearer ")) {
    return res.status(401).json({ error: "No token provided" });
  }
  const token = header.split(" ")[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const result = await query(
      `SELECT u.is_active, u.token_version, r.name AS role_name
       FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = $1`,
      [decoded.id]
    );
    if (!result.rows.length) {
      return res.status(401).json({ error: "Account no longer exists" });
    }
    const user = result.rows[0];
    if (!user.is_active) {
      return res.status(403).json({ error: "This account has been disabled" });
    }
    if ((decoded.tv ?? 0) !== user.token_version) {
      return res.status(401).json({ error: "Session expired. Please log in again." });
    }

    req.user = { id: decoded.id, email: decoded.email, role: user.role_name };
    next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
};

// Usage: authorize("admin", "placement_officer")
export const authorize = (...allowedRoles) => (req, res, next) => {
  if (!req.user || !allowedRoles.includes(req.user.role)) {
    return res.status(403).json({ error: "Forbidden: insufficient role" });
  }
  next();
};
