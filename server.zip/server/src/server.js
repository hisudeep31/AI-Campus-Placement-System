import app from "./app.js";
import dotenv from "dotenv";
import { ensureAdminAccount } from "./utils/seedAdmin.js";

dotenv.config();

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    await ensureAdminAccount();
    app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
  } catch (err) {
    console.error("Failed to start server:", err);
    process.exit(1);
  }
};

startServer();
