import { Router } from "express";
import { authenticate, authorize } from "../middleware/auth.js";
import { query } from "../config/db.js";
import { validate, createDriveSchema } from "../utils/validation.js";
import { logActivity } from "../utils/activityLog.js";
import { notify } from "../utils/notify.js";

// V3 Phase 5 module: campus placement drives (a scheduled event where one
// or more companies interview on-site/virtually on a given date). Full
// registration/attendance/outcome workflow is built out in Phase 5 — this
// file carries the base CRUD + registration so the route is real and
// usable from day one rather than a placeholder.
const router = Router();
router.use(authenticate);

// GET /api/drives — list all drives (any authenticated role)
router.get("/", async (req, res, next) => {
  try {
    const result = await query(
      `SELECT d.*,
        (SELECT count(*) FROM drive_registrations dr WHERE dr.drive_id = d.id) AS registered_count
       FROM placement_drives d ORDER BY d.drive_date ASC NULLS LAST`
    );
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
});

// GET /api/drives/:id
router.get("/:id", async (req, res, next) => {
  try {
    const driveRes = await query(`SELECT * FROM placement_drives WHERE id = $1`, [req.params.id]);
    if (!driveRes.rows.length) return res.status(404).json({ error: "Drive not found" });

    const companies = await query(
      `SELECT dc.company_id, c.company_name, dc.job_id, j.title AS job_title
       FROM drive_companies dc
       JOIN companies c ON c.id = dc.company_id
       LEFT JOIN jobs j ON j.id = dc.job_id
       WHERE dc.drive_id = $1`,
      [req.params.id]
    );
    res.json({ ...driveRes.rows[0], companies: companies.rows });
  } catch (err) {
    next(err);
  }
});

// POST /api/drives — placement officer/admin only
router.post("/", authorize("placement_officer", "admin"), validate(createDriveSchema), async (req, res, next) => {
  try {
    const { title, description, drive_date, registration_deadline, min_cgpa, eligible_departments } = req.body;
    const result = await query(
      `INSERT INTO placement_drives
         (title, description, drive_date, registration_deadline, min_cgpa, eligible_departments, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [title, description, drive_date, registration_deadline, min_cgpa, eligible_departments || [], req.user.id]
    );
    await logActivity(req.user.id, "drive.created", { drive_id: result.rows[0].id, title });

    // Tell every approved student the drive is open for registration (one bulk insert).
    await query(
      `INSERT INTO notifications (user_id, title, message)
       SELECT u.id, 'New placement drive', $1 FROM users u JOIN students s ON s.user_id = u.id WHERE u.is_approved = TRUE`,
      [`"${title}" is open for registration${drive_date ? ` (drive date ${String(drive_date).slice(0, 10)})` : ""}. Check the Drives tab.`]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    next(err);
  }
});

// POST /api/drives/:id/companies — attach a company (and optionally a job) to a drive
router.post("/:id/companies", authorize("placement_officer", "admin"), async (req, res, next) => {
  try {
    const { company_id, job_id } = req.body;
    if (!company_id) return res.status(400).json({ error: "company_id is required" });
    await query(
      `INSERT INTO drive_companies (drive_id, company_id, job_id) VALUES ($1,$2,$3)
       ON CONFLICT (drive_id, company_id) DO UPDATE SET job_id = EXCLUDED.job_id`,
      [req.params.id, company_id, job_id || null]
    );
    res.status(201).json({ message: "Company added to drive" });
  } catch (err) {
    next(err);
  }
});

// POST /api/drives/:id/register — student self-registers for a drive
router.post("/:id/register", authorize("student"), async (req, res, next) => {
  try {
    const studentRes = await query(`SELECT id, cgpa, department FROM students WHERE user_id = $1`, [req.user.id]);
    if (!studentRes.rows.length) return res.status(404).json({ error: "Student profile not found" });
    const student = studentRes.rows[0];

    const driveRes = await query(`SELECT * FROM placement_drives WHERE id = $1`, [req.params.id]);
    if (!driveRes.rows.length) return res.status(404).json({ error: "Drive not found" });
    const drive = driveRes.rows[0];

    // Server-side eligibility enforcement — mirrors the job-application
    // eligibility checks elsewhere in the app; never trust the UI alone.
    if (drive.registration_deadline && new Date(drive.registration_deadline) < new Date()) {
      return res.status(400).json({ error: "Registration for this drive has closed" });
    }
    if (drive.min_cgpa != null && student.cgpa != null && Number(student.cgpa) < Number(drive.min_cgpa)) {
      return res.status(403).json({ error: `This drive requires a minimum CGPA of ${drive.min_cgpa}` });
    }
    if (
      drive.eligible_departments &&
      drive.eligible_departments.length &&
      !drive.eligible_departments.includes(student.department)
    ) {
      return res.status(403).json({ error: "Your department is not eligible for this drive" });
    }

    const reg = await query(
      `INSERT INTO drive_registrations (drive_id, student_id) VALUES ($1,$2)
       ON CONFLICT (drive_id, student_id) DO NOTHING RETURNING *`,
      [req.params.id, student.id]
    );
    if (!reg.rows.length) return res.status(409).json({ error: "You're already registered for this drive" });

    await notify(req.user.id, "Drive registration confirmed", `You're registered for "${drive.title}".`);
    await logActivity(req.user.id, "drive.registered", { drive_id: req.params.id });
    res.status(201).json(reg.rows[0]);
  } catch (err) {
    next(err);
  }
});

// GET /api/drives/:id/attendance — officer/admin view registrations+attendance
router.get("/:id/attendance", authorize("placement_officer", "admin"), async (req, res, next) => {
  try {
    const result = await query(
      `SELECT r.id AS registration_id, s.full_name, s.department, r.registered_at,
              a.attended, a.outcome
       FROM drive_registrations r
       JOIN students s ON s.id = r.student_id
       LEFT JOIN drive_attendance a ON a.registration_id = r.id
       WHERE r.drive_id = $1 ORDER BY s.full_name`,
      [req.params.id]
    );
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
});

// PATCH /api/drives/attendance/:registrationId — mark attendance/outcome
router.patch("/attendance/:registrationId", authorize("placement_officer", "admin"), async (req, res, next) => {
  try {
    const { attended, outcome } = req.body;
    const result = await query(
      `INSERT INTO drive_attendance (registration_id, attended, outcome)
       VALUES ($1,$2,$3)
       ON CONFLICT (registration_id) DO UPDATE SET attended = EXCLUDED.attended, outcome = EXCLUDED.outcome, marked_at = now()
       RETURNING *`,
      [req.params.registrationId, attended ?? true, outcome || null]
    );
    res.json(result.rows[0]);
  } catch (err) {
    next(err);
  }
});

export default router;
