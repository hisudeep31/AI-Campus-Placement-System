import { Router } from "express";
import { authenticate } from "../middleware/auth.js";
import {
  getResumeMeta,
  downloadResume,
  deleteResume,
  listResumesForStudent,
  setDefaultResume,
} from "../controllers/resume.controller.js";

const router = Router();

// All resume routes require authentication; fine-grained ownership/role
// checks happen inside the controller (see resume.controller.js) because
// "can this user see this specific resume" depends on data (did their
// company receive an application from this student?), not just their role.
router.use(authenticate);

router.get("/student/:studentId", listResumesForStudent);
router.get("/:id", getResumeMeta);
router.get("/:id/download", downloadResume);
router.patch("/:id/default", setDefaultResume);
router.delete("/:id", deleteResume);

export default router;
