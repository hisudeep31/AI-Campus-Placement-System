import { Router } from "express";
import { authenticate } from "../middleware/auth.js";
import { downloadCompanyDocument } from "../controllers/verification.controller.js";

const router = Router();
router.use(authenticate);
router.get("/documents/:id/download", downloadCompanyDocument);

export default router;
