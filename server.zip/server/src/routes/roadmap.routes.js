import { Router } from "express";
import { authenticate, authorize } from "../middleware/auth.js";
import axios from "axios";
import { query } from "../config/db.js";
import { logActivity } from "../utils/activityLog.js";

// V3 Phase 3 module: skill-gap learning roadmaps. A roadmap is generated
// (see ai-service job_recommender / server-side gap logic, built out in
// Phase 3) as an ordered list of steps the student can check off.
const router = Router();
router.use(authenticate);

// POST /api/roadmaps/generate  body: { job_id }
// Builds a roadmap from the gap between the student's skills and the job's
// required skills (mandatory skills first), via the AI service.
router.post("/generate", authorize("student"), async (req, res, next) => {
  try {
    const { job_id } = req.body;
    if (!job_id) return res.status(400).json({ error: "job_id is required" });

    const studentRes = await query(
      `SELECT s.id, array_remove(array_agg(sk.name), NULL) AS skills FROM students s
       LEFT JOIN student_skills ss ON ss.student_id = s.id
       LEFT JOIN skills sk ON sk.id = ss.skill_id
       WHERE s.user_id=$1 GROUP BY s.id`, [req.user.id]);
    if (!studentRes.rows.length) return res.status(404).json({ error: "Student profile not found" });

    const jobSkills = await query(
      `SELECT sk.name, js.is_mandatory FROM job_skills js JOIN skills sk ON sk.id = js.skill_id
       WHERE js.job_id=$1`, [job_id]);
    if (!jobSkills.rows.length) return res.status(400).json({ error: "This job has no required skills to build a roadmap from" });

    const have = new Set(studentRes.rows[0].skills.map((s) => s.toLowerCase()));
    const missing = jobSkills.rows.filter((r) => !have.has(r.name.toLowerCase()));
    if (!missing.length) return res.json({ message: "You already have every required skill for this job", steps: [] });

    const aiRes = await axios.post(`${process.env.AI_SERVICE_URL}/roadmap/generate`, {
      missing_skills: missing.map((m) => m.name),
      mandatory_skills: missing.filter((m) => m.is_mandatory).map((m) => m.name),
    });

    const saved = await query(
      `INSERT INTO learning_roadmaps (student_id, job_id, steps) VALUES ($1,$2,$3) RETURNING *`,
      [studentRes.rows[0].id, job_id, JSON.stringify(aiRes.data.steps)]);
    await logActivity(req.user.id, "roadmap.generated", { job_id, steps: aiRes.data.steps.length });
    res.status(201).json(saved.rows[0]);
  } catch (err) { next(err); }
});

// GET /api/roadmaps/me — the logged-in student's roadmaps
router.get("/me", authorize("student"), async (req, res, next) => {
  try {
    const studentRes = await query(`SELECT id FROM students WHERE user_id = $1`, [req.user.id]);
    if (!studentRes.rows.length) return res.status(404).json({ error: "Student profile not found" });

    const result = await query(
      `SELECT r.*,
        (SELECT count(*) FROM learning_progress p WHERE p.roadmap_id = r.id AND p.completed) AS completed_steps,
        jsonb_array_length(r.steps) AS total_steps
       FROM learning_roadmaps r WHERE r.student_id = $1 ORDER BY r.created_at DESC`,
      [studentRes.rows[0].id]
    );
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
});

// GET /api/roadmaps/:id — a single roadmap with step-level progress
router.get("/:id", async (req, res, next) => {
  try {
    const roadmapRes = await query(`SELECT * FROM learning_roadmaps WHERE id = $1`, [req.params.id]);
    if (!roadmapRes.rows.length) return res.status(404).json({ error: "Roadmap not found" });
    const roadmap = roadmapRes.rows[0];

    const studentRes = await query(`SELECT user_id FROM students WHERE id = $1`, [roadmap.student_id]);
    const isOwner = studentRes.rows.length && studentRes.rows[0].user_id === req.user.id;
    if (!isOwner && !["placement_officer", "admin"].includes(req.user.role)) {
      return res.status(403).json({ error: "You don't have permission to view this roadmap" });
    }

    const progress = await query(`SELECT step_index, completed, completed_at FROM learning_progress WHERE roadmap_id = $1`, [req.params.id]);
    res.json({ ...roadmap, progress: progress.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /api/roadmaps/:id/steps/:stepIndex — toggle a step's completion
router.patch("/:id/steps/:stepIndex", authorize("student"), async (req, res, next) => {
  try {
    const roadmapRes = await query(`SELECT * FROM learning_roadmaps WHERE id = $1`, [req.params.id]);
    if (!roadmapRes.rows.length) return res.status(404).json({ error: "Roadmap not found" });

    const studentRes = await query(`SELECT user_id FROM students WHERE id = $1`, [roadmapRes.rows[0].student_id]);
    if (!studentRes.rows.length || studentRes.rows[0].user_id !== req.user.id) {
      return res.status(403).json({ error: "Only the owning student can update this roadmap" });
    }

    const { completed } = req.body;
    const result = await query(
      `INSERT INTO learning_progress (roadmap_id, step_index, completed, completed_at)
       VALUES ($1,$2,$3,$4)
       ON CONFLICT (roadmap_id, step_index)
       DO UPDATE SET completed = EXCLUDED.completed, completed_at = EXCLUDED.completed_at
       RETURNING *`,
      [req.params.id, req.params.stepIndex, Boolean(completed), completed ? new Date() : null]
    );
    res.json(result.rows[0]);
  } catch (err) {
    next(err);
  }
});

export default router;
