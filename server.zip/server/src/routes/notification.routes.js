import { Router } from "express";
import { authenticate } from "../middleware/auth.js";
import { listMyNotifications, unreadCount, markRead, markAllRead } from "../controllers/notification.controller.js";

import { query } from "../config/db.js";

const router = Router();
router.use(authenticate); // any authenticated role can read their own notifications

router.get("/me", listMyNotifications);
router.get("/me/unread-count", unreadCount);
router.patch("/:id/read", markRead);
router.patch("/read-all", markAllRead);

// GET/PUT /api/notifications/preferences — per-user channel toggles
router.get("/preferences", async (req, res, next) => {
  try {
    const r = await query(`SELECT email_enabled, in_app_enabled FROM notification_preferences WHERE user_id=$1`, [req.user.id]);
    res.json(r.rows[0] || { email_enabled: true, in_app_enabled: true });
  } catch (err) { next(err); }
});

router.put("/preferences", async (req, res, next) => {
  try {
    const email_enabled = req.body.email_enabled !== false;
    const in_app_enabled = req.body.in_app_enabled !== false;
    const r = await query(
      `INSERT INTO notification_preferences (user_id, email_enabled, in_app_enabled) VALUES ($1,$2,$3)
       ON CONFLICT (user_id) DO UPDATE SET email_enabled=EXCLUDED.email_enabled, in_app_enabled=EXCLUDED.in_app_enabled
       RETURNING email_enabled, in_app_enabled`,
      [req.user.id, email_enabled, in_app_enabled]
    );
    res.json(r.rows[0]);
  } catch (err) { next(err); }
});

export default router;
