import { Router } from "express";
import { authenticate, authorize } from "../middleware/auth.js";
import { query } from "../config/db.js";
import { logActivity } from "../utils/activityLog.js";

// V3 Phase 7 module: alumni directory. Deliberately has NO separate login
// role (see schema.sql comment on the `alumni` table) — entries are
// maintained by officers/admins, and read access is open to any
// authenticated user (students benefit most from browsing it for
// mentorship/networking, per the blueprint's intent).
const router = Router();
router.use(authenticate);

router.get("/", async (req, res, next) => {
  try {
    const { department, mentorship_only } = req.query;
    const conditions = [];
    const params = [];
    if (department) {
      params.push(department);
      conditions.push(`department = $${params.length}`);
    }
    if (mentorship_only === "true") {
      conditions.push(`mentorship_available = TRUE`);
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const result = await query(`SELECT * FROM alumni ${where} ORDER BY graduation_year DESC NULLS LAST`, params);
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
});

router.post("/", authorize("placement_officer", "admin"), async (req, res, next) => {
  try {
    const {
      full_name, graduation_year, department, current_organization,
      job_role, industry, mentorship_available, contact_email, linkedin_url,
    } = req.body;
    if (!full_name) return res.status(400).json({ error: "full_name is required" });

    const result = await query(
      `INSERT INTO alumni
        (full_name, graduation_year, department, current_organization, job_role,
         industry, mentorship_available, contact_email, linkedin_url, added_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [full_name, graduation_year || null, department || null, current_organization || null,
       job_role || null, industry || null, Boolean(mentorship_available), contact_email || null,
       linkedin_url || null, req.user.id]
    );
    await logActivity(req.user.id, "alumni.added", { alumni_id: result.rows[0].id, full_name });
    res.status(201).json(result.rows[0]);
  } catch (err) {
    next(err);
  }
});

router.put("/:id", authorize("placement_officer", "admin"), async (req, res, next) => {
  try {
    const existing = await query(`SELECT * FROM alumni WHERE id = $1`, [req.params.id]);
    if (!existing.rows.length) return res.status(404).json({ error: "Alumni record not found" });
    const current = existing.rows[0];
    const merged = { ...current, ...req.body };

    const result = await query(
      `UPDATE alumni SET full_name=$1, graduation_year=$2, department=$3, current_organization=$4,
         job_role=$5, industry=$6, mentorship_available=$7, contact_email=$8, linkedin_url=$9
       WHERE id=$10 RETURNING *`,
      [merged.full_name, merged.graduation_year, merged.department, merged.current_organization,
       merged.job_role, merged.industry, merged.mentorship_available, merged.contact_email,
       merged.linkedin_url, req.params.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    next(err);
  }
});

router.delete("/:id", authorize("placement_officer", "admin"), async (req, res, next) => {
  try {
    await query(`DELETE FROM alumni WHERE id = $1`, [req.params.id]);
    res.json({ message: "Alumni record deleted" });
  } catch (err) {
    next(err);
  }
});

export default router;
