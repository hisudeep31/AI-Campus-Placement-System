import { Router } from "express";
import rateLimit from "express-rate-limit";
import { register, login, me, refresh, logout } from "../controllers/auth.controller.js";
import { authenticate } from "../middleware/auth.js";
import { validate, registerSchema, loginSchema } from "../utils/validation.js";

const router = Router();

// V3: rate-limit the two endpoints an attacker would actually brute-force.
// Kept generous enough not to lock out a classroom of students behind the
// same campus NAT/proxy hitting login around the same time.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many attempts. Please try again in a few minutes." },
});

router.post("/register", authLimiter, validate(registerSchema), register);
router.post("/login", authLimiter, validate(loginSchema), login);
router.post("/refresh", refresh);
router.post("/logout", logout);
router.get("/me", authenticate, me);

export default router;
