import express from "express";
import cors from "cors";
import morgan from "morgan";
import helmet from "helmet";
import dotenv from "dotenv";
import fs from "fs";

import authRoutes from "./routes/auth.routes.js";
import studentRoutes from "./routes/student.routes.js";
import companyRoutes from "./routes/company.routes.js";
import officerRoutes from "./routes/officer.routes.js";
import jobRoutes from "./routes/job.routes.js";
import adminRoutes from "./routes/admin.routes.js";
import notificationRoutes from "./routes/notification.routes.js";
import resumeRoutes from "./routes/resume.routes.js";
import driveRoutes from "./routes/drive.routes.js";
import alumniRoutes from "./routes/alumni.routes.js";
import roadmapRoutes from "./routes/roadmap.routes.js";
import verificationRoutes from "./routes/verification.routes.js";
import { notFound, errorHandler } from "./middleware/errorHandler.js";
import { logger } from "./utils/logger.js";

dotenv.config();

if (!fs.existsSync("uploads")) fs.mkdirSync("uploads");

const app = express();

// V3: helmet sets a sane set of security headers (X-Content-Type-Options,
// HSTS, disables X-Powered-By, etc). contentSecurityPolicy is left off by
// default since this API serves JSON, not HTML, to a separately-hosted
// frontend — a strict default CSP here would have no effect and just adds
// noise; it's something to tighten per-deployment if this API ever serves
// HTML directly.
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CLIENT_URL || "*", credentials: true }));
app.use(express.json());
app.use(morgan("dev"));

// V3: resumes used to be served from this public static mount with no
// authentication at all — anyone who guessed or leaked a URL could read
// any student's resume. That mount is removed; resume files are now only
// reachable through resume.routes.js, which checks ownership/role before
// streaming a file back (see controllers/resume.controller.js).
// NOTE: other upload types (company logos, etc., if added later) that are
// genuinely meant to be public can still get their own narrow static
// mount — just never one that serves the whole uploads/ directory.

app.get("/health", (req, res) => res.json({ status: "ok" }));

app.use("/api/auth", authRoutes);
app.use("/api/students", studentRoutes);
app.use("/api/companies", companyRoutes);
app.use("/api/officer", officerRoutes);
app.use("/api/jobs", jobRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/resumes", resumeRoutes);
app.use("/api/drives", driveRoutes);
app.use("/api/alumni", alumniRoutes);
app.use("/api/roadmaps", roadmapRoutes);
app.use("/api/verification", verificationRoutes);

app.use(notFound);
app.use(errorHandler);

logger.info("Express app configured");

export default app;
