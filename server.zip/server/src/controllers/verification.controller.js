import path from "path";
import fs from "fs";
import { query } from "../config/db.js";
import { notify } from "../utils/notify.js";
import { logActivity } from "../utils/activityLog.js";

// ---------- Company side ----------

// POST /api/companies/me/documents  (multipart: file "document", field doc_type)
export const uploadCompanyDocument = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: "document file is required" });
    const docType = (req.body.doc_type || "other").slice(0, 50);
    const companyRes = await query(`SELECT id FROM companies WHERE user_id=$1`, [req.user.id]);
    if (!companyRes.rows.length) return res.status(404).json({ error: "Company profile not found" });

    // file_url stores the server-local path; it is never web-served. Access
    // goes through downloadCompanyDocument below (company owner / officer / admin).
    const result = await query(
      `INSERT INTO company_documents (company_id, doc_type, file_url) VALUES ($1,$2,$3)
       RETURNING id, doc_type, uploaded_at`,
      [companyRes.rows[0].id, docType, req.file.path]
    );
    // A re-submission moves a rejected company back into the review queue.
    await query(
      `UPDATE companies SET verification_status='pending' WHERE id=$1 AND verification_status='rejected'`,
      [companyRes.rows[0].id]
    );
    await logActivity(req.user.id, "company.document_uploaded", { doc_type: docType });
    res.status(201).json(result.rows[0]);
  } catch (err) { next(err); }
};

// GET /api/companies/me/documents
export const listMyDocuments = async (req, res, next) => {
  try {
    const result = await query(
      `SELECT d.id, d.doc_type, d.uploaded_at, c.verification_status
       FROM companies c LEFT JOIN company_documents d ON d.company_id = c.id
       WHERE c.user_id=$1 ORDER BY d.uploaded_at DESC`,
      [req.user.id]
    );
    const status = result.rows[0]?.verification_status || "pending";
    res.json({ verification_status: status, documents: result.rows.filter((r) => r.id).map(({ verification_status, ...d }) => d) });
  } catch (err) { next(err); }
};

// ---------- Shared download (company owner, officer, admin) ----------

// GET /api/verification/documents/:id/download
export const downloadCompanyDocument = async (req, res, next) => {
  try {
    const result = await query(
      `SELECT d.file_url, c.user_id AS owner_user_id FROM company_documents d
       JOIN companies c ON c.id = d.company_id WHERE d.id=$1`,
      [req.params.id]
    );
    if (!result.rows.length) return res.status(404).json({ error: "Document not found" });
    const { file_url, owner_user_id } = result.rows[0];
    const privileged = ["placement_officer", "admin"].includes(req.user.role);
    if (!privileged && owner_user_id !== req.user.id) {
      return res.status(403).json({ error: "You don't have permission to view this document" });
    }
    if (!fs.existsSync(file_url)) return res.status(404).json({ error: "File is missing from storage" });
    res.download(path.resolve(file_url));
  } catch (err) { next(err); }
};

// ---------- Officer side ----------

// GET /api/officer/verification?status=pending
export const listVerificationQueue = async (req, res, next) => {
  try {
    const { status = "pending" } = req.query;
    const result = await query(
      `SELECT c.id, c.company_name, c.industry, c.website, c.verification_status, c.verified_at, u.email,
              COALESCE(json_agg(json_build_object('id', d.id, 'doc_type', d.doc_type, 'uploaded_at', d.uploaded_at))
                       FILTER (WHERE d.id IS NOT NULL), '[]') AS documents
       FROM companies c
       JOIN users u ON u.id = c.user_id
       LEFT JOIN company_documents d ON d.company_id = c.id
       WHERE c.verification_status = $1
       GROUP BY c.id, u.email ORDER BY c.company_name`,
      [status]
    );
    res.json(result.rows);
  } catch (err) { next(err); }
};

// PATCH /api/officer/verification/:companyId  body: { status: verified|rejected, reason? }
export const setVerification = async (req, res, next) => {
  try {
    const { status, reason } = req.body;
    if (!["verified", "rejected"].includes(status)) {
      return res.status(400).json({ error: "status must be 'verified' or 'rejected'" });
    }
    const result = await query(
      `UPDATE companies SET verification_status=$1::varchar, verified_at = CASE WHEN $1::varchar = 'verified' THEN now() ELSE NULL END,
              verified_by = $2
       WHERE id=$3 RETURNING id, company_name, user_id, verification_status`,
      [status, req.user.id, req.params.companyId]
    );
    if (!result.rows.length) return res.status(404).json({ error: "Company not found" });
    const c = result.rows[0];
    await notify(
      c.user_id,
      status === "verified" ? "Company verified" : "Verification rejected",
      status === "verified"
        ? "Your company has been verified. A 'Verified' badge now shows on your job postings."
        : `Your verification was rejected${reason ? `: ${reason}` : ""}. Upload corrected documents to resubmit.`
    );
    await logActivity(req.user.id, "company.verification_changed", { company_id: c.id, status, reason: reason || null });
    res.json(c);
  } catch (err) { next(err); }
};
