import { query, pool } from "../config/db.js";
import { notify } from "../utils/notify.js";
import { logActivity } from "../utils/activityLog.js";
import { getPagination, sendPaginated } from "../utils/pagination.js";

// GET /api/jobs  (public/browsable, with filters)
// V3: paginated (?page=&limit=) now that the open-jobs list can grow
// without bound — previously this fetched every open job in one query.
export const listJobs = async (req, res, next) => {
  try {
    const { search, location, job_type, min_salary } = req.query;
    const { page, limit, offset } = getPagination(req);
    const conditions = ["j.status = 'open'"];
    const params = [];
    if (search) { params.push(`%${search}%`); conditions.push(`(j.title ILIKE $${params.length} OR j.description ILIKE $${params.length})`); }
    if (location) { params.push(`%${location}%`); conditions.push(`j.location ILIKE $${params.length}`); }
    if (job_type) { params.push(job_type); conditions.push(`j.job_type = $${params.length}`); }
    if (min_salary) { params.push(min_salary); conditions.push(`(j.salary_max IS NULL OR j.salary_max >= $${params.length})`); }
    const whereClause = conditions.join(" AND ");

    const countResult = await query(
      `SELECT count(*) FROM jobs j WHERE ${whereClause}`,
      params
    );
    const total = parseInt(countResult.rows[0].count, 10);

    params.push(limit, offset);
    const result = await query(
      `SELECT j.*, c.company_name, c.logo_url, c.verification_status,
              array_remove(array_agg(sk.name), NULL) AS required_skills
       FROM jobs j
       JOIN companies c ON c.id = j.company_id
       LEFT JOIN job_skills js ON js.job_id = j.id
       LEFT JOIN skills sk ON sk.id = js.skill_id
       WHERE ${whereClause}
       GROUP BY j.id, c.company_name, c.logo_url, c.verification_status
       ORDER BY j.created_at DESC
       LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );
    sendPaginated(res, result.rows, { page, limit, total });
  } catch (err) { next(err); }
};

// GET /api/jobs/:id
export const getJob = async (req, res, next) => {
  try {
    const result = await query(
      `SELECT j.*, c.company_name, c.logo_url, c.verification_status, c.description AS company_description,
              array_remove(array_agg(sk.name), NULL) AS required_skills
       FROM jobs j
       JOIN companies c ON c.id = j.company_id
       LEFT JOIN job_skills js ON js.job_id = j.id
       LEFT JOIN skills sk ON sk.id = js.skill_id
       WHERE j.id = $1
       GROUP BY j.id, c.company_name, c.logo_url, c.verification_status, c.description`,
      [req.params.id]
    );
    if (!result.rows.length) return res.status(404).json({ error: "Job not found" });
    res.json(result.rows[0]);
  } catch (err) { next(err); }
};

// POST /api/jobs/:id/apply  (student only)
// Previously this only checked for a duplicate application. The job posting
// form captures min_cgpa and application_deadline, but nothing enforced
// them — a student could apply to a closed job, past its deadline, or below
// the CGPA cutoff. Fixed here.
export const applyToJob = async (req, res, next) => {
  const client = await pool.connect();
  try {
    const jobId = req.params.id;

    const jobRes = await client.query(
      `SELECT j.*, c.company_name FROM jobs j JOIN companies c ON c.id = j.company_id WHERE j.id = $1`,
      [jobId]
    );
    if (!jobRes.rows.length) return res.status(404).json({ error: "Job not found" });
    const job = jobRes.rows[0];

    if (job.status !== "open") {
      return res.status(400).json({ error: "This job is no longer accepting applications" });
    }
    if (job.application_deadline && new Date(job.application_deadline) < new Date()) {
      return res.status(400).json({ error: "The application deadline for this job has passed" });
    }

    const studentRes = await client.query(
      "SELECT id, cgpa FROM students WHERE user_id=$1", [req.user.id]
    );
    if (!studentRes.rows.length) return res.status(404).json({ error: "Student profile not found" });
    const student = studentRes.rows[0];

    if (job.min_cgpa != null && (student.cgpa == null || Number(student.cgpa) < Number(job.min_cgpa))) {
      return res.status(400).json({
        error: `This job requires a minimum CGPA of ${job.min_cgpa}. ${
          student.cgpa == null ? "Add your CGPA to your profile first." : `Your profile CGPA is ${student.cgpa}.`
        }`,
      });
    }

    const dup = await client.query(
      "SELECT id FROM applications WHERE student_id=$1 AND job_id=$2", [student.id, jobId]
    );
    if (dup.rows.length) return res.status(409).json({ error: "Already applied to this job" });

    const result = await client.query(
      `INSERT INTO applications (student_id, job_id) VALUES ($1,$2) RETURNING *`,
      [student.id, jobId]
    );

    // Notify the company that a new applicant came in.
    const companyUserRes = await client.query(
      `SELECT user_id FROM companies WHERE id = $1`, [job.company_id]
    );
    if (companyUserRes.rows.length) {
      await notify(
        companyUserRes.rows[0].user_id,
        "New applicant",
        `A student applied to your "${job.title}" posting.`
      );
    }
    await logActivity(req.user.id, "application.created", { job_id: jobId });

    res.status(201).json(result.rows[0]);
  } catch (err) { next(err); } finally { client.release(); }
};
