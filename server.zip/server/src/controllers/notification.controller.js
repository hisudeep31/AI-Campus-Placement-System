import { query } from "../config/db.js";

// GET /api/notifications/me?limit=20
export const listMyNotifications = async (req, res, next) => {
  try {
    const limit = Math.min(parseInt(req.query.limit, 10) || 20, 100);
    const result = await query(
      `SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT $2`,
      [req.user.id, limit]
    );
    res.json(result.rows);
  } catch (err) { next(err); }
};

// GET /api/notifications/me/unread-count
export const unreadCount = async (req, res, next) => {
  try {
    const result = await query(
      `SELECT COUNT(*) FROM notifications WHERE user_id=$1 AND is_read=false`,
      [req.user.id]
    );
    res.json({ count: parseInt(result.rows[0].count, 10) });
  } catch (err) { next(err); }
};

// PATCH /api/notifications/:id/read
export const markRead = async (req, res, next) => {
  try {
    const result = await query(
      `UPDATE notifications SET is_read=true WHERE id=$1 AND user_id=$2 RETURNING *`,
      [req.params.id, req.user.id]
    );
    if (!result.rows.length) return res.status(404).json({ error: "Notification not found" });
    res.json(result.rows[0]);
  } catch (err) { next(err); }
};

// PATCH /api/notifications/read-all
export const markAllRead = async (req, res, next) => {
  try {
    await query(`UPDATE notifications SET is_read=true WHERE user_id=$1 AND is_read=false`, [req.user.id]);
    res.json({ message: "All notifications marked read" });
  } catch (err) { next(err); }
};
