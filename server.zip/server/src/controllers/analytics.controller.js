
import { query } from "../config/db.js";
import { logActivity } from "../utils/activityLog.js";
import { readinessForStudent } from "../utils/readiness.js";

const num = (v) => (v === null || v === undefined ? null : Number(v));

// Consistent status check for selected applications.
// Handles values such as "selected", "Selected", and " selected ".
const SELECTED_STATUS = "LOWER(BTRIM(a.status)) = 'selected'";

// GET /api/officer/analytics/salary
export const salaryAnalytics = async (req, res, next) => {
  try {
    const [summary, byDept, byCompany] = await Promise.all([
      query(`
        SELECT COUNT(*)::int AS offers_with_salary,
               ROUND(AVG(final_salary), 2) AS average,
               percentile_cont(0.5) WITHIN GROUP (ORDER BY final_salary) AS median,
               MAX(final_salary) AS highest,
               MIN(final_salary) AS lowest
        FROM applications
        WHERE LOWER(BTRIM(status)) = 'selected'
          AND final_salary IS NOT NULL
      `),

      query(`
        SELECT s.department,
               ROUND(AVG(a.final_salary), 2) AS average,
               COUNT(*)::int AS offers
        FROM applications a
        JOIN students s ON s.id = a.student_id
        WHERE LOWER(BTRIM(a.status)) = 'selected'
          AND a.final_salary IS NOT NULL
        GROUP BY s.department
        ORDER BY average DESC
      `),

      query(`
        SELECT c.company_name,
               ROUND(AVG(a.final_salary), 2) AS average,
               COUNT(*)::int AS offers
        FROM applications a
        JOIN jobs j ON j.id = a.job_id
        JOIN companies c ON c.id = j.company_id
        WHERE LOWER(BTRIM(a.status)) = 'selected'
          AND a.final_salary IS NOT NULL
        GROUP BY c.company_name
        ORDER BY average DESC
        LIMIT 10
      `),
    ]);

    const s = summary.rows[0];

    res.json({
      summary: {
        offers_with_salary: s.offers_with_salary,
        average: num(s.average),
        median: num(s.median),
        highest: num(s.highest),
        lowest: num(s.lowest),
      },
      by_department: byDept.rows.map((r) => ({
        ...r,
        average: num(r.average),
      })),
      by_company: byCompany.rows.map((r) => ({
        ...r,
        average: num(r.average),
      })),
    });
  } catch (err) {
    next(err);
  }
};

// GET /api/officer/analytics/yearly
// Placements by graduation year
export const yearlyAnalytics = async (req, res, next) => {
  try {
    const result = await query(`
      SELECT
        s.graduation_year AS year,
        COUNT(DISTINCT s.id)::int AS total_students,
        COUNT(
          DISTINCT CASE
            WHEN LOWER(BTRIM(a.status)) = 'selected' THEN s.id
          END
        )::int AS placed_students
      FROM students s
      LEFT JOIN applications a ON a.student_id = s.id
      WHERE s.graduation_year IS NOT NULL
      GROUP BY s.graduation_year
      ORDER BY s.graduation_year
    `);

    res.json(
      result.rows.map((r) => ({
        ...r,
        placement_percentage: r.total_students
          ? Math.round((r.placed_students / r.total_students) * 100)
          : 0,
      }))
    );
  } catch (err) {
    next(err);
  }
};

// GET /api/officer/analytics/status-distribution
// Application status pie chart
export const statusDistribution = async (req, res, next) => {
  try {
    const result = await query(`
      SELECT
        LOWER(BTRIM(status)) AS name,
        COUNT(*)::int AS value
      FROM applications
      WHERE status IS NOT NULL
      GROUP BY LOWER(BTRIM(status))
      ORDER BY value DESC
    `);

    res.json(result.rows);
  } catch (err) {
    next(err);
  }
};

// GET /api/officer/analytics/readiness
// Cohort distribution + students needing attention
export const readinessAnalytics = async (req, res, next) => {
  try {
    const students = await query(`
      SELECT
        s.id,
        s.full_name,
        s.department,
        EXISTS (
          SELECT 1
          FROM applications a
          WHERE a.student_id = s.id
            AND LOWER(BTRIM(a.status)) = 'selected'
        ) AS placed
      FROM students s
      JOIN users u ON u.id = s.user_id
      WHERE u.is_approved = TRUE
    `);

    const scored = [];

    for (const st of students.rows) {
      const r = await readinessForStudent(query, st.id);

      if (r) {
        scored.push({
          ...st,
          readiness: r.readiness,
          band: r.band,
          top_gap: r.suggestions[0] || null,
        });
      }
    }

    const distribution = {
      strong: 0,
      developing: 0,
      needs_attention: 0,
    };

    scored.forEach((s) => {
      distribution[s.band] += 1;
    });

    const avg = scored.length
      ? Math.round(
          (scored.reduce((a, s) => a + s.readiness, 0) / scored.length) * 10
        ) / 10
      : 0;

    const needsAttention = scored
      .filter((s) => !s.placed && s.band === "needs_attention")
      .sort((a, b) => a.readiness - b.readiness)
      .slice(0, 25);

    res.json({
      average_readiness: avg,
      distribution,
      needs_attention: needsAttention,
      method: "rule_based",
    });
  } catch (err) {
    next(err);
  }
};

// GET /api/officer/reports/pdf
// One-page summary report
export const exportPdfReport = async (req, res, next) => {
  try {
    // Imported lazily so the API still boots if pdfkit isn't installed yet.
    let PDFDocument;

    try {
      PDFDocument = (await import("pdfkit")).default;
    } catch {
      return res.status(501).json({
        error: "PDF export needs the 'pdfkit' package. Run `npm install` in /server.",
      });
    }

    const [totals, depts, recruiters, salary] = await Promise.all([
      query(`
        SELECT
          (SELECT COUNT(*) FROM students)::int AS students,
          (
            SELECT COUNT(DISTINCT student_id)
            FROM applications
            WHERE LOWER(BTRIM(status)) = 'selected'
          )::int AS placed,
          (SELECT COUNT(*) FROM companies)::int AS companies,
          (SELECT COUNT(*) FROM jobs)::int AS jobs
      `),

      query(`
        SELECT
          s.department,
          COUNT(DISTINCT s.id)::int AS total,
          COUNT(
            DISTINCT CASE
              WHEN LOWER(BTRIM(a.status)) = 'selected'
              THEN a.student_id
            END
          )::int AS placed
        FROM students s
        LEFT JOIN applications a ON a.student_id = s.id
        GROUP BY s.department
        ORDER BY s.department
      `),

      query(`
        SELECT
          c.company_name,
          COUNT(a.id) FILTER (
            WHERE LOWER(BTRIM(a.status)) = 'selected'
          )::int AS offers
        FROM companies c
        LEFT JOIN jobs j ON j.company_id = c.id
        LEFT JOIN applications a ON a.job_id = j.id
        GROUP BY c.company_name
        ORDER BY offers DESC
        LIMIT 8
      `),

      query(`
        SELECT
          ROUND(AVG(final_salary), 0) AS average,
          MAX(final_salary) AS highest
        FROM applications
        WHERE LOWER(BTRIM(status)) = 'selected'
          AND final_salary IS NOT NULL
      `),
    ]);

    const t = totals.rows[0];

    const pct = t.students
      ? Math.round((t.placed / t.students) * 100)
      : 0;

    const doc = new PDFDocument({ margin: 50 });

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      'attachment; filename="placement_summary.pdf"'
    );

    doc.pipe(res);

    doc.fontSize(20).text("Campus Placement Summary", {
      align: "left",
    });

    doc
      .fontSize(9)
      .fillColor("#666")
      .text(`Generated ${new Date().toLocaleString()}`)
      .fillColor("#000")
      .moveDown();

    doc.fontSize(13).text("Overview").moveDown(0.3).fontSize(11);

    doc.text(
      `Students: ${t.students}    Placed: ${t.placed} (${pct}%)    Companies: ${t.companies}    Jobs: ${t.jobs}`
    );

    const sal = salary.rows[0];

    if (sal.average !== null) {
      doc.text(
        `Average package: ${Number(sal.average).toLocaleString()}    Highest: ${
          sal.highest !== null
            ? Number(sal.highest).toLocaleString()
            : "N/A"
        }`
      );
    }

    doc.moveDown();

    doc
      .fontSize(13)
      .text("Department-wise placement")
      .moveDown(0.3)
      .fontSize(11);

    depts.rows.forEach((d) => {
      const p = d.total
        ? Math.round((d.placed / d.total) * 100)
        : 0;

      doc.text(
        `${d.department || "Unspecified"}: ${d.placed}/${d.total} placed (${p}%)`
      );
    });

    doc.moveDown();

    doc
      .fontSize(13)
      .text("Top recruiters (offers)")
      .moveDown(0.3)
      .fontSize(11);

    recruiters.rows.forEach((r) => {
      doc.text(`${r.company_name}: ${r.offers}`);
    });

    doc.end();

    await logActivity(req.user.id, "report.exported", {
      type: "pdf_summary",
    });
  } catch (err) {
    next(err);
  }
};
