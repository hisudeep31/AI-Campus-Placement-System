import test from "node:test";
import assert from "node:assert/strict";
import { assertTransition, allowedNext, STATES, TRANSITIONS, statusUpdateSql } from "../src/utils/pipeline.js";
import { computeReadiness, READINESS_WEIGHTS } from "../src/utils/readiness.js";
import { buildIcs } from "../src/utils/ics.js";
import { getPagination } from "../src/utils/pagination.js";

// ---- application state machine ----
test("every state has a transition entry", () => {
  for (const s of STATES) assert.ok(s in TRANSITIONS, s);
});

test("legal and illegal transitions", () => {
  assert.equal(assertTransition("applied", "shortlisted"), null);
  assert.equal(assertTransition("shortlisted", "interview_scheduled"), null);
  assert.equal(assertTransition("interview_completed", "selected"), null);
  assert.match(assertTransition("applied", "selected"), /Cannot move/);
  assert.match(assertTransition("applied", "bogus"), /Invalid status/);
});

test("terminal states cannot change", () => {
  assert.deepEqual(allowedNext("selected"), []);
  assert.deepEqual(allowedNext("rejected"), []);
  assert.match(assertTransition("rejected", "shortlisted"), /final status/);
});

test("rescheduling an interview is allowed, other self-transitions are not", () => {
  assert.equal(assertTransition("interview_scheduled", "interview_scheduled"), null);
  assert.match(assertTransition("applied", "applied"), /already/);
});

test("status update SQL uses the given parameter numbers", () => {
  const sql = statusUpdateSql(2, 5);
  assert.match(sql, /\$2::varchar/);
  assert.match(sql, /\$5::text/);
});

// ---- readiness ----
test("readiness weights sum to 100", () => {
  assert.equal(Object.values(READINESS_WEIGHTS).reduce((a, b) => a + b, 0), 100);
});

test("readiness is bounded and rule-based", () => {
  const max = computeReadiness({ cgpa: 10, skillCount: 20, atsScore: 100, projectCount: 9, mockAvg: 100, certificateCount: 5, experienceCount: 3 });
  assert.equal(max.readiness, 100);
  assert.equal(max.method, "rule_based");
  const min = computeReadiness({});
  assert.equal(min.readiness, 0);
  assert.equal(min.band, "needs_attention");
});

test("readiness suggestions target the biggest gaps", () => {
  const r = computeReadiness({ cgpa: 9, skillCount: 10, atsScore: 90, projectCount: 3, mockAvg: 0, certificateCount: 2, experienceCount: 1 });
  assert.equal(r.suggestions.length, 1);
  assert.match(r.suggestions[0], /mock interviews/i);
});

// ---- ICS ----
test("ics escapes special characters and uses CRLF", () => {
  const ics = buildIcs([{ uid: "u1", start: "2026-12-01T10:00:00Z", summary: "Interview, A; B", description: "line1\nline2" }]);
  assert.ok(ics.includes("SUMMARY:Interview\\, A\\; B"));
  assert.match(ics, /DESCRIPTION:line1\\nline2/);
  assert.ok(ics.includes("\r\n"));
  assert.match(ics, /DTSTART:20261201T100000Z/);
  assert.match(ics, /DTEND:20261201T110000Z/);
});

test("ics skips events with an invalid date", () => {
  assert.doesNotMatch(buildIcs([{ uid: "x", start: "not-a-date", summary: "s" }]), /BEGIN:VEVENT/);
});

// ---- pagination ----
test("pagination defaults, clamps, and offsets", () => {
  assert.deepEqual(getPagination({ query: {} }), { page: 1, limit: 50, offset: 0 });
  assert.deepEqual(getPagination({ query: { page: "3", limit: "10" } }), { page: 3, limit: 10, offset: 20 });
  assert.equal(getPagination({ query: { limit: "99999" } }).limit, 200);
  assert.equal(getPagination({ query: { page: "-4", limit: "abc" } }).page, 1);
});
