"""
OPTIONAL scaffold: train a real placement-outcome model once you have real data.

Why this is a scaffold and not a shipped model: a trustworthy model needs
real historical outcomes (which past students were placed, with what
profile). A fresh install has none, and training on invented data would
produce a model that sounds authoritative but means nothing. Until then the
app uses the transparent rule-based readiness score (server/src/utils/readiness.js).

Usage (after you've collected at least MIN_ROWS real, labelled rows):
    python train_readiness_model.py data.csv

data.csv columns:
    cgpa, skill_count, ats_score, project_count, mock_avg, certificate_count, placed
where `placed` is 1/0 for whether that (past) student was placed.

It reports cross-validated accuracy/ROC-AUC so you can judge whether the model
beats the baseline before wiring it in (writing predictions with
method='ml_model' into prediction_results). Predictions are guidance only and
must not be used as a hiring or admissions decision.
"""
import sys

MIN_ROWS = 200
FEATURES = ["cgpa", "skill_count", "ats_score", "project_count", "mock_avg", "certificate_count"]


def main(path: str):
    import csv
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import cross_val_score

    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    if len(rows) < MIN_ROWS:
        sys.exit(f"Refusing to train: {len(rows)} rows < {MIN_ROWS}. Collect more real outcomes first.")

    X = [[float(r[c] or 0) for c in FEATURES] for r in rows]
    y = [int(r["placed"]) for r in rows]
    if len(set(y)) < 2:
        sys.exit("Refusing to train: labels contain only one class.")

    model = RandomForestClassifier(n_estimators=200, random_state=42, class_weight="balanced")
    acc = cross_val_score(model, X, y, cv=5, scoring="accuracy")
    auc = cross_val_score(model, X, y, cv=5, scoring="roc_auc")
    base = max(sum(y), len(y) - sum(y)) / len(y)
    print(f"rows={len(rows)} baseline_accuracy={base:.3f}")
    print(f"cv accuracy={acc.mean():.3f} (+/-{acc.std():.3f})  roc_auc={auc.mean():.3f}")
    if acc.mean() <= base + 0.02:
        print("Model does not meaningfully beat the majority-class baseline — do NOT deploy it.")
        return

    model.fit(X, y)
    import pickle
    with open("readiness_model.pkl", "wb") as f:
        pickle.dump({"features": FEATURES, "model": model}, f)
    print("Saved readiness_model.pkl")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
