"""
ATS (Applicant Tracking System) style resume scoring.

V3: rebuilt as a job-specific weighted scoring engine, per the blueprint's
exact weighting: Skills 35, Education 15, Experience 20, Projects 15,
Structure 10, Certifications 5 (= 100 total). This replaces the V2
four-dimension scorer (sections/keywords/achievements/length). It is
still a transparent, heuristic scorer on purpose — not a black box, and
not dressed up as a trained ML model — so every number comes with
"evidence": the concrete facts that produced it, shown to the student so
the score is something they can act on rather than a mysterious verdict.
"""
import re

DEFAULT_TARGET_KEYWORDS = [
    "Python", "JavaScript", "React", "Node.js", "Docker", "Kubernetes",
    "AWS", "SQL", "REST API", "Git", "Machine Learning", "CI/CD",
]

ACHIEVEMENT_PATTERNS = [
    r"\b\d+%",             # e.g. "improved performance by 20%"
    r"\b\d+x\b",           # e.g. "3x faster"
    r"\$\d+",              # dollar figures
    r"\b\d{2,}\+?\s*(users|customers|requests|records|downloads)\b",
]

WEIGHTS = {
    "skills": 35,
    "education": 15,
    "experience": 20,
    "projects": 15,
    "structure": 10,
    "certifications": 5,
}


def _skills_score(resume_skills: list, target_keywords: list) -> dict:
    target_set = {k.lower() for k in target_keywords}
    have_set = {s.lower() for s in resume_skills}
    matched = sorted(k for k in target_keywords if k.lower() in have_set)
    missing = [k for k in target_keywords if k.lower() not in have_set]
    coverage = len(matched) / len(target_set) if target_set else 1
    score = coverage * WEIGHTS["skills"]
    return {
        "score": round(score, 2),
        "max": WEIGHTS["skills"],
        "evidence": f"Matched {len(matched)}/{len(target_set) or 0} target skills: "
                    f"{', '.join(matched) if matched else 'none'}",
        "matched_keywords": matched,
        "missing_keywords": missing,
    }


def _education_score(education: list) -> dict:
    if not education:
        return {"score": 0.0, "max": WEIGHTS["education"], "evidence": "No education entries detected"}
    has_cgpa = any(e.get("cgpa") for e in education)
    has_degree = any(e.get("degree") for e in education)
    ratio = (int(has_degree) + int(has_cgpa)) / 2
    score = max(ratio, 0.5) * WEIGHTS["education"]  # presence alone is worth something
    evidence = f"{len(education)} education entr{'y' if len(education) == 1 else 'ies'} found"
    if has_degree:
        evidence += "; degree identified"
    if has_cgpa:
        evidence += "; CGPA/GPA identified"
    return {"score": round(score, 2), "max": WEIGHTS["education"], "evidence": evidence}


def _experience_score(experience: list, full_text: str) -> dict:
    if not experience:
        return {"score": 0.0, "max": WEIGHTS["experience"], "evidence": "No work experience entries detected"}
    quantified = sum(
        1 for e in experience
        if any(re.search(p, " ".join(e.get("details", [])), re.IGNORECASE) for p in ACHIEVEMENT_PATTERNS)
    )
    base_ratio = min(len(experience) / 3, 1)  # 3+ roles = full base credit
    bonus_ratio = min(quantified / max(len(experience), 1), 1) * 0.3
    score = min(base_ratio + bonus_ratio, 1) * WEIGHTS["experience"]
    evidence = f"{len(experience)} role(s) detected"
    if quantified:
        evidence += f"; {quantified} with quantified impact (numbers/%/metrics)"
    else:
        evidence += "; none show quantified impact yet"
    return {"score": round(score, 2), "max": WEIGHTS["experience"], "evidence": evidence}


def _projects_score(projects: list) -> dict:
    if not projects:
        return {"score": 0.0, "max": WEIGHTS["projects"], "evidence": "No projects detected"}
    described = sum(1 for p in projects if len(p.get("description", "")) > 20)
    ratio = min(len(projects) / 3, 1) * 0.6 + min(described / max(len(projects), 1), 1) * 0.4
    score = ratio * WEIGHTS["projects"]
    return {
        "score": round(score, 2),
        "max": WEIGHTS["projects"],
        "evidence": f"{len(projects)} project(s) detected, {described} with a real description",
    }


def _structure_score(parsed: dict) -> dict:
    full_text = parsed.get("full_text", "")
    word_count = len(full_text.split())
    contact = parsed.get("contact", {})
    has_contact = bool(contact.get("email")) and bool(contact.get("phone"))

    # Ideal resume: ~350–900 words (roughly 1-2 pages)
    if 350 <= word_count <= 900:
        length_ratio = 1.0
    elif word_count < 350:
        length_ratio = word_count / 350
    else:
        overflow_penalty = min((word_count - 900) / 900, 1)
        length_ratio = 1 - overflow_penalty * 0.5

    section_count = sum(1 for k in ("education_raw", "experience_raw", "projects_raw") if parsed.get(k))
    section_ratio = section_count / 3

    ratio = length_ratio * 0.5 + section_ratio * 0.3 + (0.2 if has_contact else 0)
    score = min(ratio, 1) * WEIGHTS["structure"]
    evidence = f"{word_count} words, {section_count}/3 core sections present"
    evidence += ", contact info complete" if has_contact else ", contact info incomplete"
    return {"score": round(score, 2), "max": WEIGHTS["structure"], "evidence": evidence}


def _certifications_score(certifications: list) -> dict:
    count = len(certifications)
    ratio = min(count / 2, 1)  # 2+ certs = full credit
    score = ratio * WEIGHTS["certifications"]
    return {
        "score": round(score, 2),
        "max": WEIGHTS["certifications"],
        "evidence": f"{count} certification(s) detected" if count else "No certifications detected",
    }


def score_resume(parsed: dict, target_keywords: list = None) -> dict:
    """
    parsed: the dict returned by resume_parser.parse_resume() (or an
    equivalent shape reconstructed for /resume/rescore).
    """
    target_keywords = target_keywords or DEFAULT_TARGET_KEYWORDS

    skills_result = _skills_score(parsed.get("skills", []), target_keywords)
    education_result = _education_score(parsed.get("education", []))
    experience_result = _experience_score(parsed.get("experience", []), parsed.get("full_text", ""))
    projects_result = _projects_score(parsed.get("projects", []))
    structure_result = _structure_score(parsed)
    certifications_result = _certifications_score(parsed.get("certifications", []))

    breakdown = {
        "skills": skills_result,
        "education": education_result,
        "experience": experience_result,
        "projects": projects_result,
        "structure": structure_result,
        "certifications": certifications_result,
    }
    total = round(sum(v["score"] for v in breakdown.values()), 2)

    suggestions = []
    if skills_result["missing_keywords"]:
        suggestions.append(f"Add relevant keywords: {', '.join(skills_result['missing_keywords'][:5])}")
    if experience_result["score"] < WEIGHTS["experience"] * 0.5:
        suggestions.append("Add measurable impact to your experience (e.g. \"reduced load time by 30%\")")
    if education_result["score"] < WEIGHTS["education"] * 0.5:
        suggestions.append("Make sure your education section includes your degree and CGPA/GPA")
    if projects_result["score"] < WEIGHTS["projects"] * 0.5:
        suggestions.append("Add 2-3 projects with a short description of what you built and used")
    if structure_result["score"] < WEIGHTS["structure"] * 0.6:
        suggestions.append("Check resume length (aim for 350-900 words) and that contact info is present")
    if certifications_result["score"] == 0:
        suggestions.append("Consider adding relevant certifications if you have any")
    if not suggestions:
        suggestions.append("Resume looks strong across skills, education, experience, and structure")

    return {
        "overall_score": min(total, 100),
        "breakdown": breakdown,
        "missing_keywords": skills_result["missing_keywords"],
        "suggestions": suggestions,
    }
