"""
AI interview question generator (V3: difficulty + category tagging).

Default implementation is bank-based: each curated question carries a
category (technical / conceptual / behavioral / scenario), a difficulty
(beginner / intermediate / advanced), and the key `concepts` a good answer
should touch. Those concepts are what answer_evaluator.py scores against,
so evaluation stays transparent rather than a black box.

If ANTHROPIC_API_KEY is set, questions are instead LLM-generated (tagged
with the requested difficulty); on any failure we fall back to the bank.
"""
import json
import os
import random

DIFFICULTIES = ["beginner", "intermediate", "advanced"]

# (question, category, difficulty, concepts)
QUESTION_BANK = {
    "python": [
        ("What is the difference between a list and a tuple in Python?", "conceptual", "beginner",
         ["mutable", "immutable", "hashable", "performance"]),
        ("Explain Python's GIL and how it affects multithreading.", "technical", "advanced",
         ["global interpreter lock", "thread", "cpu-bound", "multiprocessing", "i/o"]),
        ("How does Python's garbage collection work?", "technical", "intermediate",
         ["reference counting", "cycle", "generational", "gc"]),
    ],
    "javascript": [
        ("Explain the difference between '==' and '===' in JavaScript.", "conceptual", "beginner",
         ["type coercion", "strict", "equality", "type"]),
        ("What is a closure, and can you give an example?", "conceptual", "intermediate",
         ["scope", "function", "lexical", "variable", "outer"]),
        ("How does the event loop work in JavaScript?", "technical", "advanced",
         ["call stack", "queue", "async", "microtask", "single-threaded"]),
    ],
    "react": [
        ("What is React's Virtual DOM and why does it improve performance?", "conceptual", "intermediate",
         ["virtual dom", "diff", "reconciliation", "re-render", "real dom"]),
        ("Explain the difference between state and props.", "conceptual", "beginner",
         ["state", "props", "immutable", "parent", "component"]),
        ("What are React hooks and why were they introduced?", "technical", "intermediate",
         ["usestate", "useeffect", "functional component", "class", "reuse"]),
    ],
    "node.js": [
        ("How does Node.js handle asynchronous I/O?", "technical", "intermediate",
         ["event loop", "non-blocking", "callback", "libuv", "single thread"]),
        ("What is middleware in Express.js?", "conceptual", "beginner",
         ["request", "response", "next", "function", "pipeline"]),
        ("Explain the difference between process.nextTick and setImmediate.", "technical", "advanced",
         ["event loop", "phase", "microtask", "queue", "before"]),
    ],
    "sql": [
        ("What is the difference between INNER JOIN and LEFT JOIN?", "conceptual", "beginner",
         ["matching", "null", "all rows", "left table", "inner"]),
        ("Explain database normalization and why it matters.", "conceptual", "intermediate",
         ["redundancy", "anomaly", "normal form", "table", "integrity"]),
        ("What is an index, and how does it speed up queries?", "technical", "intermediate",
         ["b-tree", "lookup", "scan", "write", "trade-off"]),
    ],
    "rest api": [
        ("Explain REST API and its guiding constraints.", "conceptual", "intermediate",
         ["stateless", "client-server", "resource", "http", "uniform interface", "cache"]),
        ("What is the difference between PUT and PATCH?", "conceptual", "beginner",
         ["replace", "partial", "idempotent", "update"]),
        ("How would you version a public REST API?", "scenario", "advanced",
         ["url", "header", "backward", "deprecat", "version"]),
    ],
    "machine learning": [
        ("Explain the difference between Random Forest and a single Decision Tree.", "conceptual", "intermediate",
         ["ensemble", "bagging", "overfit", "variance", "trees"]),
        ("What is overfitting, and how can you prevent it?", "conceptual", "beginner",
         ["training", "generalize", "regularization", "cross-validation", "more data"]),
        ("Explain the bias-variance tradeoff.", "conceptual", "advanced",
         ["bias", "variance", "underfit", "overfit", "complexity"]),
    ],
    "docker": [
        ("What is the difference between a Docker image and a container?", "conceptual", "beginner",
         ["image", "container", "template", "instance", "running"]),
        ("Explain the purpose of a Dockerfile vs docker-compose.yml.", "technical", "intermediate",
         ["build", "image", "multi-container", "services", "orchestrat"]),
    ],
    "aws": [
        ("What's the difference between an EC2 instance and a Lambda function?", "conceptual", "intermediate",
         ["server", "serverless", "scaling", "billing", "event"]),
        ("How would you design a highly available web app on AWS?", "scenario", "advanced",
         ["availability zone", "load balancer", "auto scaling", "database", "replica"]),
    ],
}

GENERIC_QUESTIONS = [
    ("Tell me about your final year / most significant project.", "behavioral", "beginner",
     ["problem", "built", "technology", "challenge", "result"]),
    ("Describe a time you faced a technical challenge — how did you solve it?", "behavioral", "intermediate",
     ["situation", "action", "result", "learned", "debug"]),
    ("How do you approach debugging an issue you've never seen before?", "scenario", "intermediate",
     ["reproduce", "logs", "isolate", "hypothesis", "test"]),
    ("Where do you see yourself contributing most in your first 6 months?", "behavioral", "beginner",
     ["learn", "contribute", "team", "skills", "goal"]),
]

# Flat lookup so the evaluator can find the expected concepts for a question.
CONCEPTS_BY_QUESTION = {q: concepts for bank in QUESTION_BANK.values() for q, _, _, concepts in bank}
CONCEPTS_BY_QUESTION.update({q: concepts for q, _, _, concepts in GENERIC_QUESTIONS})


def _as_item(entry) -> dict:
    q, category, difficulty, concepts = entry
    return {"question": q, "category": category, "difficulty": difficulty, "concepts": concepts}


def _generate_template(skills: list, num_questions: int, difficulty: str) -> list:
    pool = []
    for skill in [s.lower() for s in skills or []]:
        pool.extend(QUESTION_BANK.get(skill, []))

    def pick(candidates, n):
        random.shuffle(candidates)
        return candidates[:n]

    # Prefer the requested difficulty, then fill from adjacent levels so a
    # thin bank still yields a full set rather than failing.
    preferred = [e for e in pool if e[2] == difficulty]
    others = [e for e in pool if e[2] != difficulty]
    chosen = pick(preferred, num_questions)
    if len(chosen) < num_questions:
        chosen += pick(others, num_questions - len(chosen))

    if len(chosen) < num_questions:
        generic = [g for g in GENERIC_QUESTIONS if g not in chosen]
        chosen += pick(generic, num_questions - len(chosen))

    return [_as_item(e) for e in chosen[:num_questions]]


def _generate_with_claude(skills: list, num_questions: int, difficulty: str) -> list:
    import anthropic  # lazy, optional dependency

    client = anthropic.Anthropic()
    skills_str = ", ".join(skills) if skills else "general software engineering"
    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1200,
        messages=[{
            "role": "user",
            "content": (
                f"Generate exactly {num_questions} {difficulty}-level interview questions for a "
                f"candidate with these skills: {skills_str}. Return ONLY a JSON array of objects "
                'with keys "question", "category" (technical|conceptual|behavioral|scenario) and '
                '"concepts" (array of 3-6 lowercase key terms a good answer should mention).'
            ),
        }],
    )
    items = json.loads(message.content[0].text)
    return [{
        "question": i["question"],
        "category": i.get("category", "technical"),
        "difficulty": difficulty,
        "concepts": i.get("concepts", []),
    } for i in items][:num_questions]


def generate_questions(skills: list, num_questions: int = 6, difficulty: str = "intermediate") -> list:
    if difficulty not in DIFFICULTIES:
        difficulty = "intermediate"
    if os.getenv("ANTHROPIC_API_KEY"):
        try:
            return _generate_with_claude(skills, num_questions, difficulty)
        except Exception:
            pass  # fall back to the curated bank
    return _generate_template(skills, num_questions, difficulty)
