"""
Resume parsing utilities.

Uses pdfplumber for text extraction and a regex/keyword-based approach for
structuring the resume into sections, entities, and extracting skills.
This deliberately avoids requiring large NLP model downloads for a
dev/demo setup (no spaCy/transformer weights to fetch), while still going
beyond "one blob of text per section" — see parse_resume() for the
structured entity extraction (name, per-entry education/experience/
projects) that V3 adds on top of the V2 raw-section-text parser.

OCR fallback: if pdfplumber extracts almost no text (a strong signal the
PDF is a scanned image rather than real text), we try pytesseract as a
fallback. pytesseract is imported lazily and only used if it's installed
AND a tesseract binary is available on the machine — if either is
missing, we skip OCR and return what pdfplumber got, rather than crashing
the whole parse. This keeps the feature "real when available" instead of
a silent lie about accuracy.
"""
import re
from typing import IO 

import pdfplumber

# Curated skill vocabulary. Extend this list (or load from DB) to widen
# what the parser can recognize. Matching is case-insensitive word-boundary.
KNOWN_SKILLS = [
    "Python", "JavaScript", "TypeScript", "Java", "C++", "C#", "Go", "Rust",
    "React", "Angular", "Vue", "Node.js", "Express", "Django", "FastAPI",
    "Flask", "Spring Boot", "Docker", "Kubernetes", "AWS", "Azure", "GCP",
    "SQL", "PostgreSQL", "MySQL", "MongoDB", "Redis", "GraphQL", "REST API",
    "Machine Learning", "Deep Learning", "NLP", "TensorFlow", "PyTorch",
    "Scikit-learn", "Pandas", "NumPy", "Git", "Linux", "CI/CD", "Jenkins",
    "Tailwind CSS", "HTML", "CSS", "Redux", "Next.js", "Terraform",
]

SECTION_HEADERS = {
    "education": ["education", "academic background"],
    "experience": ["experience", "work experience", "employment"],
    "projects": ["projects", "academic projects"],
    "certifications": ["certifications", "certificates", "licenses"],
    "skills": ["skills", "technical skills", "skill set"],
}

DEGREE_PATTERN = re.compile(
    r"\b(B\.?Tech|M\.?Tech|B\.?E|M\.?E|B\.?Sc|M\.?Sc|B\.?C\.?A|M\.?C\.?A|MBA|Ph\.?D|Bachelor|Master|Diploma)\b",
    re.IGNORECASE,
)
CGPA_PATTERN = re.compile(r"\b(?:CGPA|GPA)\s*[:\-]?\s*(\d(?:\.\d{1,2})?)\s*(?:/\s*(\d{1,2}))?", re.IGNORECASE)
YEAR_PATTERN = re.compile(r"\b(?:19|20)\d{2}\b")
DATE_RANGE_PATTERN = re.compile(
    r"([A-Za-z]{3,9}\.?\s*\d{4}|\d{4})\s*(?:-|to|–)\s*([A-Za-z]{3,9}\.?\s*\d{4}|\d{4}|Present|present|Current|current)"
)


def extract_text(file: IO) -> str:
    text_parts = []
    with pdfplumber.open(file) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text() or ""
            text_parts.append(page_text)
    return "\n".join(text_parts)


def _ocr_fallback(file: IO) -> str:
    """
    Attempts OCR on each page image when normal text extraction yields
    almost nothing (a scanned/photographed resume). Returns "" if
    pytesseract or the underlying tesseract binary isn't available —
    callers must treat an empty result as "OCR unavailable", not "resume
    is blank".
    """
    try:
        import pytesseract  # lazy import: optional dependency
    except ImportError:
        return ""

    try:
        file.seek(0)
        text_parts = []
        with pdfplumber.open(file) as pdf:
            for page in pdf.pages:
                try:
                    pil_image = page.to_image(resolution=200).original
                    text_parts.append(pytesseract.image_to_string(pil_image))
                except Exception:
                    # A single bad page shouldn't sink the whole OCR pass.
                    continue
        return "\n".join(text_parts)
    except Exception:
        # Covers a missing tesseract binary (pytesseract raises
        # TesseractNotFoundError) and any other OCR-time failure.
        return ""


def _split_sections(text: str) -> dict:
    lines = text.split("\n")
    sections = {"header": []}
    current = "header"
    for line in lines:
        stripped = line.strip()
        lower = stripped.lower().rstrip(":")
        matched_section = None
        for key, headers in SECTION_HEADERS.items():
            if lower in headers or (len(lower) < 40 and any(lower.startswith(h) for h in headers)):
                matched_section = key
                break
        if matched_section:
            current = matched_section
            sections.setdefault(current, [])
            continue
        sections.setdefault(current, []).append(stripped)
    return sections


def extract_skills(text: str) -> list:
    found = []
    lower_text = text.lower()
    for skill in KNOWN_SKILLS:
        pattern = r"\b" + re.escape(skill.lower()) + r"\b"
        if re.search(pattern, lower_text):
            found.append(skill)
    return sorted(set(found))


def extract_email_phone(text: str) -> dict:
    email_matches = re.findall(r"[\w.+-]+@[\w-]+\.[\w.-]+", text)
    phone_matches = re.findall(r"(\+?\d[\d\-\s()]{8,}\d)", text)
    return {
        "email": email_matches[0] if email_matches else None,
        "phone": phone_matches[0].strip() if phone_matches else None,
        "emails": list(dict.fromkeys(email_matches)),
        "phones": [p.strip() for p in dict.fromkeys(phone_matches)],
    }


def extract_full_name(sections: dict) -> str:
    """
    Heuristic: a resume's name is almost always the first non-empty,
    short, mostly-alphabetic line before any contact info — so we scan the
    header lines for the first line that looks like a name rather than an
    email/phone/address, and stop as soon as we hit one.
    """
    for line in sections.get("header", []):
        clean = line.strip()
        if not clean or len(clean) > 60:
            continue
        if "@" in clean or re.search(r"\d{3,}", clean):
            continue
        letters_ratio = sum(c.isalpha() or c.isspace() for c in clean) / max(len(clean), 1)
        if letters_ratio > 0.8 and 2 <= len(clean.split()) <= 5:
            return clean
    return ""


def _parse_education_entries(raw: str) -> list:
    """Splits the education section into per-entry dicts: {degree, institution, cgpa, year}."""
    entries = []
    for line in [l.strip() for l in raw.split("\n") if l.strip()]:
        degree_match = DEGREE_PATTERN.search(line)
        cgpa_match = CGPA_PATTERN.search(line)
        year_matches = YEAR_PATTERN.findall(line)
        if not (degree_match or cgpa_match or year_matches):
            continue
        # Institution: whatever's left after stripping out the degree token
        # and any trailing numbers — a rough heuristic, not NER-grade, but
        # good enough to show the student *something* structured to confirm
        # or correct rather than a wall of raw text.
        institution = line
        if degree_match:
            institution = (line[:degree_match.start()] + line[degree_match.end():]).strip(" ,-|")
        entries.append({
            "raw": line,
            "degree": degree_match.group(0) if degree_match else None,
            "institution": institution or None,
            "cgpa": cgpa_match.group(1) if cgpa_match else None,
            "year": year_matches[-1] if year_matches else None,
        })
    return entries


def _parse_experience_entries(raw: str) -> list:
    """Splits the experience section into per-entry dicts: {role_or_company, duration}."""
    entries = []
    for line in [l.strip() for l in raw.split("\n") if l.strip()]:
        date_match = DATE_RANGE_PATTERN.search(line)
        if not date_match and not YEAR_PATTERN.search(line):
            # A bullet point under an entry (no dates of its own) —
            # attach it to the previous entry as a detail line instead of
            # discarding it.
            if entries and (line.startswith(("-", "•", "*")) or len(line.split()) > 4):
                entries[-1].setdefault("details", []).append(line.lstrip("-•* "))
            continue
        duration = date_match.group(0) if date_match else (YEAR_PATTERN.search(line).group(0))
        title_line = line.replace(duration, "").strip(" ,-|")
        entries.append({"raw": line, "role_or_company": title_line or None, "duration": duration, "details": []})
    return entries


def _parse_projects_entries(raw: str) -> list:
    """Groups project-section lines into {title, description} by treating short
    lines as titles and subsequent longer lines as that project's description."""
    entries = []
    for line in [l.strip() for l in raw.split("\n") if l.strip()]:
        is_title_like = len(line) < 70 and not line.startswith(("-", "•", "*"))
        if is_title_like and (not entries or entries[-1].get("description")):
            entries.append({"title": line.lstrip("-•* "), "description": ""})
        elif entries:
            sep = " " if entries[-1]["description"] else ""
            entries[-1]["description"] += sep + line.lstrip("-•* ")
        else:
            entries.append({"title": line.lstrip("-•* "), "description": ""})
    return entries


def parse_resume(file: IO) -> dict:
    text = extract_text(file)
    ocr_used = False

    # Scanned/image-only PDFs come back from pdfplumber nearly empty even
    # though the file clearly has content — that's the trigger for OCR.
    if len(text.strip()) < 40:
        ocr_text = _ocr_fallback(file)
        if ocr_text.strip():
            text = ocr_text
            ocr_used = True

    sections = _split_sections(text)
    contact = extract_email_phone(text)
    skills = extract_skills(text)
    full_name = extract_full_name(sections)

    education_raw = "\n".join(sections.get("education", [])).strip()
    experience_raw = "\n".join(sections.get("experience", [])).strip()
    projects_raw = "\n".join(sections.get("projects", [])).strip()
    certifications_raw = "\n".join(sections.get("certifications", [])).strip()

    return {
        "raw_text_length": len(text),
        "ocr_used": ocr_used,
        "full_name": full_name,
        "contact": contact,
        "skills": skills,
        "education_raw": education_raw,
        "experience_raw": experience_raw,
        "projects_raw": projects_raw,
        "certifications_raw": certifications_raw,
        "education": _parse_education_entries(education_raw),
        "experience": _parse_experience_entries(experience_raw),
        "projects": _parse_projects_entries(projects_raw),
        "certifications": [l.strip("-•* ") for l in certifications_raw.split("\n") if l.strip()],
        "full_text": text,
    }


# NOTES on upgrading extraction quality further:
# - Swap extract_skills() to use a spaCy PhraseMatcher over a larger skill
#   ontology (e.g. ESCO or LinkedIn skills taxonomy) for better recall.
# - Use spaCy's NER (en_core_web_sm) or a resume-specific NER model for the
#   entity extraction in _parse_education_entries/_parse_experience_entries
#   instead of the regex heuristics above — those heuristics cover common
#   resume formats well but will miss unusual layouts.
# - OCR accuracy depends entirely on scan quality; this is a genuine
#   fallback, not a guarantee — always let the student review/correct the
#   structured fields rather than trusting them blindly.
