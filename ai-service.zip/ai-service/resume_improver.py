"""
Resume improvement assistant.

Important constraint (explicit, non-negotiable per the project's own
design principles): this module NEVER invents experience, achievements,
employers, numbers, or skills the student didn't write. Every suggestion
either (a) rephrases wording that's already present, using the student's
own nouns/verbs, or (b) points out a *gap* for the student to fill in
themselves (e.g. "this line has no number — can you quantify it?"). It
never fills that gap with a fabricated number or claim.
"""
import re

WEAK_OPENERS = {
    "responsible for": "Managed",
    "worked on": "Built",
    "helped with": "Contributed to",
    "duties included": "Led",
    "was involved in": "Drove",
    "tasked with": "Owned",
}

STRONG_ACTION_VERBS = [
    "led", "built", "designed", "developed", "implemented", "launched",
    "optimized", "automated", "architected", "drove", "delivered",
    "reduced", "increased", "improved", "created", "owned", "mentored",
]

QUANTIFIER_PATTERN = re.compile(r"\d")


def _rephrase_weak_opener(line: str) -> dict | None:
    lower = line.lower()
    for weak, strong in WEAK_OPENERS.items():
        if lower.startswith(weak):
            rest = line[len(weak):].lstrip(" :-")
            return {
                "original": line,
                "suggestion": f"{strong} {rest}",
                "reason": f'Passive phrasing ("{weak}...") reads as low-ownership. '
                          f'Leading with a strong verb is more direct — using your own '
                          f"wording, just reordered/reworded, not new content.",
            }
    return None


def _flag_missing_action_verb(line: str) -> dict | None:
    first_word = line.strip().split(" ")[0].lower().strip(".,:-")
    if first_word and first_word not in STRONG_ACTION_VERBS and len(line.split()) > 4:
        return {
            "original": line,
            "suggestion": None,
            "reason": f'Consider starting this line with an action verb (e.g. "{STRONG_ACTION_VERBS[0]}", '
                      f'"{STRONG_ACTION_VERBS[2]}", "{STRONG_ACTION_VERBS[9]}") instead of "{first_word}" — '
                      f"pick the verb that actually matches what you did; we won't guess for you.",
        }
    return None


def _flag_missing_quantifier(line: str) -> dict | None:
    if len(line.split()) > 6 and not QUANTIFIER_PATTERN.search(line) and "%" not in line:
        return {
            "original": line,
            "suggestion": None,
            "reason": "This line describes an action but has no number attached. If you can recall a "
                      "real figure (time saved, users affected, % improvement, team size), adding it makes "
                      "the line far more concrete — but only add a number you can actually stand behind.",
        }
    return None


def improve_experience_lines(detail_lines: list) -> list:
    """
    Takes the raw detail/bullet lines already extracted from a resume
    (never generates new ones) and returns a list of
    {original, suggestion, reason} improvement notes. `suggestion` is
    None when we're only flagging a gap rather than proposing rewording,
    which signals the frontend to show it as a prompt, not a one-click
    "apply" fix.
    """
    notes = []
    for line in detail_lines:
        clean = line.strip()
        if not clean or len(clean) < 8:
            continue
        note = _rephrase_weak_opener(clean) or _flag_missing_action_verb(clean) or _flag_missing_quantifier(clean)
        if note:
            notes.append(note)
    return notes


def improve_resume(parsed: dict) -> dict:
    """
    parsed: the dict from resume_parser.parse_resume(). Walks experience
    and project entries and returns per-entry improvement notes, plus a
    short list of resume-wide observations (missing sections, etc.) that
    mirror what the ATS scorer already flags — kept here too so this
    endpoint is useful standalone, without requiring a job to score against.
    """
    experience_notes = []
    for entry in parsed.get("experience", []):
        details = entry.get("details", []) or [entry.get("raw", "")]
        role_notes = improve_experience_lines(details)
        if role_notes:
            experience_notes.append({"role_or_company": entry.get("role_or_company"), "notes": role_notes})

    project_notes = []
    for entry in parsed.get("projects", []):
        desc = entry.get("description", "")
        if desc:
            notes = improve_experience_lines([desc])
            if notes:
                project_notes.append({"title": entry.get("title"), "notes": notes})

    general_observations = []
    if not parsed.get("certifications"):
        general_observations.append("No certifications listed — add any you've earned, even in-progress ones.")
    if not parsed.get("contact", {}).get("email"):
        general_observations.append("No email address detected — make sure your contact info is clearly visible.")
    if len(parsed.get("skills", [])) < 5:
        general_observations.append("Fewer than 5 recognizable skills found — consider listing more of your tools/technologies explicitly.")

    return {
        "experience_notes": experience_notes,
        "project_notes": project_notes,
        "general_observations": general_observations,
        "disclaimer": "These are wording and structure suggestions only. Nothing here was invented — "
                       "review each suggestion and only apply what's actually true about your own work.",
    }
