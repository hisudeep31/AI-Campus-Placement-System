"""Unit tests for the pure-logic parts of the AI service.
They need no network, DB, or model downloads. Run: `pytest ai-service/tests` (from repo root)
or `pytest tests` inside ai-service/.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest

from answer_evaluator import evaluate_answer
from ats_scorer import WEIGHTS, score_resume
from interview_generator import DIFFICULTIES, generate_questions
from job_recommender import recommend_jobs
from resume_improver import improve_resume
from roadmap_generator import generate_roadmap


def make_parsed(**over):
    base = {
        "full_text": "word " * 500,
        "skills": ["Python", "SQL", "Git"],
        "contact": {"email": "a@b.co", "phone": "9876543210"},
        "education": [{"degree": "B.Tech", "cgpa": "8.2"}],
        "experience": [{"role_or_company": "Intern", "details": ["Cut query time by 40% using indexes"]}],
        "projects": [{"title": "App", "description": "A reasonably long description of the project"}],
        "certifications": ["AWS Cloud Practitioner"],
        "education_raw": "x", "experience_raw": "x", "projects_raw": "x",
    }
    base.update(over)
    return base


# ---------- ATS scorer ----------
def test_weights_sum_to_100():
    assert sum(WEIGHTS.values()) == 100


def test_score_within_bounds_and_has_evidence():
    r = score_resume(make_parsed(), ["Python", "Docker"])
    assert 0 <= r["overall_score"] <= 100
    for dim in WEIGHTS:
        assert dim in r["breakdown"]
        assert r["breakdown"][dim]["evidence"]
        assert r["breakdown"][dim]["score"] <= r["breakdown"][dim]["max"]


def test_missing_keywords_reported():
    r = score_resume(make_parsed(), ["Python", "Docker", "Kubernetes"])
    assert r["missing_keywords"] == ["Docker", "Kubernetes"]


def test_more_matching_skills_scores_higher():
    low = score_resume(make_parsed(skills=["Python"]), ["Python", "SQL", "Git"])
    high = score_resume(make_parsed(skills=["Python", "SQL", "Git"]), ["Python", "SQL", "Git"])
    assert high["overall_score"] > low["overall_score"]


def test_empty_resume_scores_low_without_crashing():
    empty = make_parsed(full_text="", skills=[], contact={}, education=[], experience=[],
                        projects=[], certifications=[], education_raw="", experience_raw="", projects_raw="")
    r = score_resume(empty, ["Python"])
    assert r["overall_score"] < 10
    assert r["suggestions"]


# ---------- Resume improver ----------
def test_improver_never_invents_numbers():
    parsed = make_parsed(experience=[{"role_or_company": "Intern", "details": ["Responsible for the backend APIs of the app"]}])
    out = improve_resume(parsed)
    notes = out["experience_notes"][0]["notes"]
    assert notes[0]["suggestion"].startswith("Managed")
    # rewording keeps the student's own words and adds no digits
    assert not any(ch.isdigit() for ch in notes[0]["suggestion"])


def test_improver_flags_missing_quantifier_without_fabricating():
    parsed = make_parsed(experience=[{"role_or_company": "X", "details": ["Built and maintained internal dashboards for the team"]}])
    notes = improve_resume(parsed)["experience_notes"][0]["notes"]
    assert notes[0]["suggestion"] is None  # a prompt for the student, not an invented rewrite


# ---------- Answer evaluator ----------
Q = "What is the difference between a list and a tuple in Python?"


def test_empty_answer_scores_zero():
    assert evaluate_answer(Q, "idk")["overall_score"] == 0


def test_good_answer_beats_weak_answer():
    good = evaluate_answer(Q, "A list is mutable because you can change it, whereas a tuple is immutable, "
                              "which means it is hashable. For example, tuples can be dict keys.")
    weak = evaluate_answer(Q, "They are different types in python and have different uses overall.")
    assert good["overall_score"] > weak["overall_score"]
    assert "mutable" in good["feedback"]["covered_concepts"]


def test_unknown_question_reports_low_confidence():
    r = evaluate_answer("Totally novel question?", "Some reasonably long answer about various technical topics here.")
    assert r["feedback"]["confidence"] == "low"


def test_scores_bounded():
    r = evaluate_answer(Q, "mutable immutable hashable performance " * 30)
    assert 0 <= r["overall_score"] <= 100


# ---------- Interview generator ----------
@pytest.mark.parametrize("difficulty", DIFFICULTIES)
def test_generator_returns_tagged_questions(difficulty):
    qs = generate_questions(["Python", "SQL"], 4, difficulty)
    assert len(qs) == 4
    for q in qs:
        assert q["question"] and q["category"] and q["difficulty"] in DIFFICULTIES


def test_generator_pads_with_generic_when_skills_unknown():
    assert len(generate_questions(["UnknownSkill"], 3)) == 3


# ---------- Recommender (TF-IDF fallback path) ----------
JOBS = [
    {"id": "1", "title": "Backend Engineer", "description": "Build APIs", "required_skills": ["Python", "Docker"]},
    {"id": "2", "title": "UI Designer", "description": "Design screens", "required_skills": ["Figma"]},
]


def test_recommender_ranks_skill_match_first_and_explains():
    res = recommend_jobs(["Python", "SQL"], JOBS)
    assert res[0]["id"] == "1"
    assert res[0]["matched_skills"] == ["Python"]
    assert res[0]["missing_skills"] == ["Docker"]
    assert res[0]["reasons"]
    assert res[0]["method"] in ("hybrid_semantic", "hybrid_tfidf_fallback")


def test_recommender_handles_empty_inputs():
    assert recommend_jobs(["Python"], []) == []
    assert isinstance(recommend_jobs([], JOBS), list)


# ---------- Roadmap ----------
def test_roadmap_orders_mandatory_first_and_never_invents_urls():
    steps = generate_roadmap(["React", "Git", "Docker"], mandatory_skills=["Docker"])
    assert steps[0]["skill"] == "Docker" and steps[0]["priority"] == "high"
    assert all(s["resource"]["url"].startswith("https://") for s in steps)
    unknown = generate_roadmap(["ObscureTool"])[0]["resource"]
    assert unknown["curated"] is False
