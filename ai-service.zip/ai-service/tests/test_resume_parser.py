import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from resume_parser import (
    _parse_education_entries, _parse_experience_entries, _parse_projects_entries,
    _split_sections, extract_email_phone, extract_full_name, extract_skills,
)

SAMPLE = """Priya Sharma
priya@example.com | +91 98765 43210
Education
B.Tech Computer Science, ABC Institute, CGPA: 8.4, 2025
Experience
Backend Intern, Acme Corp Jun 2024 - Aug 2024
- Built REST APIs and cut response time by 30%
Projects
Placement Portal
Full-stack app using React and Node.js with PostgreSQL
Certifications
AWS Cloud Practitioner
Skills
Python, SQL
"""


def test_sections_and_name():
    sections = _split_sections(SAMPLE)
    assert extract_full_name(sections) == "Priya Sharma"
    assert "education" in sections and "experience" in sections and "projects" in sections


def test_contact_and_skills():
    c = extract_email_phone(SAMPLE)
    assert c["email"] == "priya@example.com" and c["phone"]
    assert {"Python", "SQL", "React", "Node.js", "PostgreSQL"} <= set(extract_skills(SAMPLE))


def test_education_entry_fields():
    e = _parse_education_entries("B.Tech Computer Science, ABC Institute, CGPA: 8.4, 2025")[0]
    assert e["degree"].lower().startswith("b") and e["cgpa"] == "8.4" and e["year"] == "2025"


def test_experience_entry_with_details():
    sections = _split_sections(SAMPLE)
    entries = _parse_experience_entries("\n".join(sections["experience"]))
    assert entries and entries[0]["duration"]
    assert any("30%" in d for d in entries[0]["details"])


def test_projects_grouping():
    sections = _split_sections(SAMPLE)
    projects = _parse_projects_entries("\n".join(sections["projects"]))
    assert projects[0]["title"] == "Placement Portal" and "React" in projects[0]["description"]
