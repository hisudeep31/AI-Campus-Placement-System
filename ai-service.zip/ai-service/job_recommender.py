"""
Job recommendation engine (V3: hybrid, explainable).

Final score = 0.5 * skill_overlap + 0.3 * semantic_similarity + 0.2 * tfidf_similarity

- skill_overlap: fraction of the job's required skills the student has.
  Transparent and the strongest signal for "can this student do this job".
- semantic_similarity: cosine similarity of sentence-transformer
  embeddings (student skills vs job text). Captures meaning beyond exact
  words (e.g. "backend" ~ "server-side"). OPTIONAL: the model is imported
  lazily and loaded once; if sentence-transformers isn't installed or the
  weights can't be downloaded (no network), this component is skipped and
  its weight is redistributed onto the other two — the service never fails
  because of it. The response's `method` field says which path ran.
- tfidf_similarity: lexical cosine similarity (the V2 baseline).

Every result includes matched_skills / missing_skills / reasons so the UI
can explain *why* a job was recommended instead of showing a bare number.
"""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

_MODEL = None
_MODEL_FAILED = False
MODEL_NAME = "all-MiniLM-L6-v2"


def _get_model():
    """Loads the sentence-transformer once; returns None if unavailable."""
    global _MODEL, _MODEL_FAILED
    if _MODEL is not None or _MODEL_FAILED:
        return _MODEL
    try:
        from sentence_transformers import SentenceTransformer  # lazy, optional
        _MODEL = SentenceTransformer(MODEL_NAME)
    except Exception:
        _MODEL_FAILED = True
        _MODEL = None
    return _MODEL


def _job_text(job: dict) -> str:
    skills = " ".join(job.get("required_skills", []) or [])
    return f"{job.get('title', '')} {job.get('description', '')} {skills}"


def _tfidf_scores(student_text: str, job_texts: list) -> list:
    try:
        matrix = TfidfVectorizer(stop_words="english").fit_transform([student_text] + job_texts)
    except ValueError:
        return [0.0] * len(job_texts)
    return [float(x) for x in cosine_similarity(matrix[0:1], matrix[1:])[0]]


def _semantic_scores(student_text: str, job_texts: list):
    model = _get_model()
    if model is None or not student_text.strip():
        return None
    try:
        embeddings = model.encode([student_text] + job_texts, normalize_embeddings=True)
        sims = cosine_similarity(embeddings[0:1], embeddings[1:])[0]
        return [max(float(x), 0.0) for x in sims]
    except Exception:
        return None


def _overlap(student_skills: list, required: list) -> tuple:
    have = {s.lower() for s in student_skills}
    matched = [s for s in required if s.lower() in have]
    missing = [s for s in required if s.lower() not in have]
    ratio = len(matched) / len(required) if required else 0.0
    return ratio, matched, missing


def _reasons(matched, missing, overlap_ratio, semantic):
    reasons = []
    if matched:
        reasons.append(f"You already have {len(matched)} of the required skills: {', '.join(matched[:5])}")
    if missing:
        reasons.append(f"Skills to build for this role: {', '.join(missing[:5])}")
    if semantic is not None and semantic > 0.4:
        reasons.append("Your skill profile is semantically close to this role's description")
    if not reasons:
        reasons.append("Limited skill data — add skills to your profile for better matches")
    return reasons


def recommend_jobs(student_skills: list, jobs: list, top_k: int = 10) -> list:
    if not jobs:
        return []

    student_skills = student_skills or []
    student_text = " ".join(student_skills)
    job_texts = [_job_text(j) for j in jobs]

    tfidf = _tfidf_scores(student_text, job_texts)
    semantic = _semantic_scores(student_text, job_texts)
    method = "hybrid_semantic" if semantic is not None else "hybrid_tfidf_fallback"

    results = []
    for i, job in enumerate(jobs):
        ratio, matched, missing = _overlap(student_skills, job.get("required_skills", []) or [])
        if semantic is not None:
            final = 0.5 * ratio + 0.3 * semantic[i] + 0.2 * tfidf[i]
        else:
            final = 0.65 * ratio + 0.35 * tfidf[i]
        results.append({
            **job,
            "similarity_score": round(final, 4),  # kept name for frontend compatibility
            "skill_match_percent": round(ratio * 100),
            "matched_skills": matched,
            "missing_skills": missing,
            "reasons": _reasons(matched, missing, ratio, semantic[i] if semantic else None),
            "method": method,
        })

    results.sort(key=lambda r: r["similarity_score"], reverse=True)
    return results[:top_k]
