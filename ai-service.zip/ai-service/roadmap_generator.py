"""
Skill-gap learning roadmap generator.

Turns a list of missing skills into an ordered, checkable list of steps.
Resources come from a small CURATED map of well-known, free official
docs/courses; for skills not in the map we fall back to a generic search
link rather than guessing a specific URL — we never fabricate a resource.
Ordering follows a simple dependency hint (fundamentals before
frameworks) and the job's mandatory-skills-first preference supplied by
the caller.
"""
from urllib.parse import quote_plus

CURATED_RESOURCES = {
    "python": ("Python Official Tutorial", "https://docs.python.org/3/tutorial/"),
    "javascript": ("MDN JavaScript Guide", "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide"),
    "typescript": ("TypeScript Handbook", "https://www.typescriptlang.org/docs/handbook/intro.html"),
    "react": ("React Learn", "https://react.dev/learn"),
    "node.js": ("Node.js Learn", "https://nodejs.org/en/learn"),
    "docker": ("Docker Get Started", "https://docs.docker.com/get-started/"),
    "kubernetes": ("Kubernetes Basics", "https://kubernetes.io/docs/tutorials/kubernetes-basics/"),
    "sql": ("SQLBolt Interactive Lessons", "https://sqlbolt.com/"),
    "postgresql": ("PostgreSQL Tutorial", "https://www.postgresql.org/docs/current/tutorial.html"),
    "git": ("Pro Git Book", "https://git-scm.com/book/en/v2"),
    "fastapi": ("FastAPI Tutorial", "https://fastapi.tiangolo.com/tutorial/"),
    "django": ("Django Tutorial", "https://docs.djangoproject.com/en/stable/intro/tutorial01/"),
    "mongodb": ("MongoDB University", "https://learn.mongodb.com/"),
    "machine learning": ("scikit-learn Tutorials", "https://scikit-learn.org/stable/tutorial/index.html"),
    "aws": ("AWS Skill Builder (free tier)", "https://skillbuilder.aws/"),
    "html": ("MDN HTML Guide", "https://developer.mozilla.org/en-US/docs/Learn/HTML"),
    "css": ("MDN CSS Guide", "https://developer.mozilla.org/en-US/docs/Learn/CSS"),
}

# Learn these before the things that build on them.
FOUNDATIONS = ["html", "css", "git", "sql", "python", "javascript", "java"]


def _resource_for(skill: str) -> dict:
    hit = CURATED_RESOURCES.get(skill.lower())
    if hit:
        return {"title": hit[0], "url": hit[1], "curated": True}
    return {
        "title": f"Search: learn {skill}",
        "url": f"https://www.google.com/search?q={quote_plus('learn ' + skill + ' tutorial')}",
        "curated": False,
    }


def _order_key(skill: str, mandatory: set) -> tuple:
    s = skill.lower()
    foundation_rank = FOUNDATIONS.index(s) if s in FOUNDATIONS else len(FOUNDATIONS)
    return (0 if s in mandatory else 1, foundation_rank, s)


def generate_roadmap(missing_skills: list, mandatory_skills: list = None) -> list:
    mandatory = {m.lower() for m in (mandatory_skills or [])}
    ordered = sorted(set(missing_skills), key=lambda s: _order_key(s, mandatory))
    steps = []
    for idx, skill in enumerate(ordered):
        steps.append({
            "step": idx + 1,
            "skill": skill,
            "priority": "high" if skill.lower() in mandatory else "normal",
            "action": f"Learn the fundamentals of {skill}, then build one small project that uses it",
            "estimated_effort": "1-2 weeks",
            "resource": _resource_for(skill),
        })
    return steps
