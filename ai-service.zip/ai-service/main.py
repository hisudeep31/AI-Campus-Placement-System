import io
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional

from resume_parser import parse_resume
from ats_scorer import score_resume
from resume_improver import improve_resume
from roadmap_generator import generate_roadmap
from answer_evaluator import evaluate_answer
from job_recommender import recommend_jobs
from interview_generator import generate_questions

app = FastAPI(title="Placement AI Service", version="3.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten in production to the Node API's origin
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {"status": "ok"}


def _keywords_from_csv(raw: Optional[str]) -> Optional[List[str]]:
    if not raw:
        return None
    items = [k.strip() for k in raw.split(",") if k.strip()]
    return items or None


# ---------- Resume parsing + ATS scoring ----------
# `target_keywords` is an optional comma-separated string of skills to score
# against (e.g. a specific job's required skills). When omitted, scoring
# falls back to the generic DEFAULT_TARGET_KEYWORDS list in ats_scorer.py.
# This is what makes the ATS score "job-specific" rather than one-size-fits-all.
@app.post("/resume/parse")
async def parse_resume_endpoint(file: UploadFile = File(...), target_keywords: Optional[str] = Form(None)):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF resumes are supported currently")

    contents = await file.read()
    parsed = parse_resume(io.BytesIO(contents))
    scoring = score_resume(parsed, target_keywords=_keywords_from_csv(target_keywords))

    return {
        "parsed": {
            "full_name": parsed["full_name"],
            "skills": parsed["skills"],
            "contact": parsed["contact"],
            "education": parsed["education"],
            "experience": parsed["experience"],
            "projects": parsed["projects"],
            "certifications": parsed["certifications"],
            "ocr_used": parsed["ocr_used"],
            # Full text is returned (truncated) so the caller can persist it
            # and request a re-score against a *different* job later via
            # /resume/rescore, without needing the student to re-upload the PDF.
            "full_text": parsed["full_text"][:20000],
        },
        "ats_score": scoring["overall_score"],
        "score_breakdown": scoring["breakdown"],
        "missing_keywords": scoring["missing_keywords"],
        "suggestions": scoring["suggestions"],
        "scored_against": target_keywords.split(",") if target_keywords else "default",
    }


# ---------- Re-score an already-parsed resume against a different job ----------
class RescoreRequest(BaseModel):
    full_text: str
    skills: List[str] = []
    target_keywords: List[str]
    # Structured fields persisted at upload time (resume_parsed_data). When
    # provided, rescoring is as accurate as the original parse.
    education: List[dict] = []
    experience: List[dict] = []
    projects: List[dict] = []
    certifications: List[str] = []
    contact: dict = {}


@app.post("/resume/rescore")
def rescore_resume(req: RescoreRequest):
    parsed_like = {
        "full_text": req.full_text,
        "skills": req.skills,
        "education": req.education,
        "experience": req.experience,
        "projects": req.projects,
        "certifications": req.certifications,
        "contact": req.contact,
        "education_raw": "x" if req.education else "",
        "experience_raw": "x" if req.experience else "",
        "projects_raw": "x" if req.projects else "",
    }
    scoring = score_resume(parsed_like, target_keywords=req.target_keywords or None)
    return {
        "ats_score": scoring["overall_score"],
        "score_breakdown": scoring["breakdown"],
        "missing_keywords": scoring["missing_keywords"],
        "suggestions": scoring["suggestions"],
    }


# ---------- Resume improvement assistant ----------
# Rewording/gap-flagging only; never invents content (see resume_improver.py).
class ImproveRequest(BaseModel):
    experience: List[dict] = []
    projects: List[dict] = []
    certifications: List[str] = []
    skills: List[str] = []
    contact: dict = {}


@app.post("/resume/improve")
def improve(req: ImproveRequest):
    return improve_resume(req.dict())


# ---------- Job recommendation ----------
class JobIn(BaseModel):
    id: str
    title: str
    description: Optional[str] = ""
    required_skills: Optional[List[str]] = []


class RecommendRequest(BaseModel):
    student_skills: List[str]
    jobs: List[JobIn]
    top_k: int = 10


@app.post("/jobs/recommend")
def recommend(req: RecommendRequest):
    jobs_as_dicts = [j.dict() for j in req.jobs]
    ranked = recommend_jobs(req.student_skills, jobs_as_dicts, top_k=req.top_k)
    return {"recommendations": ranked}


# ---------- Skill gap (kept in ai-service too for reuse outside the Node API) ----------
class SkillGapRequest(BaseModel):
    student_skills: List[str]
    required_skills: List[str]


@app.post("/skills/gap")
def skill_gap(req: SkillGapRequest):
    have = {s.lower() for s in req.student_skills}
    missing = [s for s in req.required_skills if s.lower() not in have]
    match_percent = (
        round(((len(req.required_skills) - len(missing)) / len(req.required_skills)) * 100)
        if req.required_skills else 100
    )
    return {"have": list(have), "missing": missing, "match_percent": match_percent}


# ---------- Interview question generation ----------
# `skills` should be the union of the student's own skills and the target
# job's required skills (the Node API computes that union — see
# student.controller.js:generateMockInterview) so gap-area questions show
# up even for skills the student hasn't listed yet.
class InterviewRequest(BaseModel):
    skills: List[str]
    num_questions: int = 6
    difficulty: str = "intermediate"  # beginner | intermediate | advanced


@app.post("/interview/generate")
def interview(req: InterviewRequest):
    questions = generate_questions(req.skills, req.num_questions, req.difficulty)
    return {"questions": questions}


# ---------- Answer evaluation (transparent, rule-based) ----------
class EvaluateRequest(BaseModel):
    question: str
    answer: str
    concepts: List[str] = []


@app.post("/interview/evaluate")
def evaluate(req: EvaluateRequest):
    return evaluate_answer(req.question, req.answer, req.concepts or None)


# ---------- Learning roadmap ----------
class RoadmapRequest(BaseModel):
    missing_skills: List[str]
    mandatory_skills: List[str] = []


@app.post("/roadmap/generate")
def roadmap(req: RoadmapRequest):
    return {"steps": generate_roadmap(req.missing_skills, req.mandatory_skills)}
