"""
Interview answer evaluator — transparent, rule-based.

Overall = 40% technical + 25% conceptual + 20% explanation + 15% completeness

- technical (40): coverage of the question's expected key concepts
  (substring match on the answer). Needs concepts; if none are known for
  a question this dimension is scored from specificity (distinct
  technical-looking terms) and `confidence` is reported as "low".
- conceptual (25): does the answer define/explain rather than just list
  terms (explanatory connectives like "because", "which means", "so that").
- explanation (20): clarity/structure — sentence count, sentence length
  sanity, examples ("for example", "e.g.").
- completeness (15): answer length relative to a reasonable target.

This is NOT a trained model and not a judgement of the candidate; it is a
practice aid whose every point is traceable to something in the answer.
"""
import re

from interview_generator import CONCEPTS_BY_QUESTION

WEIGHTS = {"technical": 40, "conceptual": 25, "explanation": 20, "completeness": 15}
CONNECTIVES = ["because", "which means", "so that", "therefore", "in order to", "this allows", "as a result", "whereas", "unlike"]
EXAMPLE_MARKERS = ["for example", "for instance", "e.g.", "such as", "like when"]


def _sentences(text: str) -> list:
    return [s.strip() for s in re.split(r"[.!?]+", text) if s.strip()]


def _technical(answer_lower: str, concepts: list) -> tuple:
    if not concepts:
        terms = set(re.findall(r"\b[a-z][a-z0-9+#.\-]{4,}\b", answer_lower))
        ratio = min(len(terms) / 25, 1)
        return ratio, [], [], "low"
    hit = [c for c in concepts if c.lower() in answer_lower]
    miss = [c for c in concepts if c.lower() not in answer_lower]
    return len(hit) / len(concepts), hit, miss, "normal"


def _conceptual(answer_lower: str) -> float:
    found = sum(1 for c in CONNECTIVES if c in answer_lower)
    return min(found / 2, 1)


def _explanation(answer: str, answer_lower: str) -> float:
    sents = _sentences(answer)
    if not sents:
        return 0.0
    avg_len = sum(len(s.split()) for s in sents) / len(sents)
    structure = min(len(sents) / 4, 1)
    length_sanity = 1.0 if 8 <= avg_len <= 30 else 0.5
    example = 1.0 if any(m in answer_lower for m in EXAMPLE_MARKERS) else 0.0
    return 0.45 * structure + 0.25 * length_sanity + 0.30 * example


def _completeness(answer: str) -> float:
    words = len(answer.split())
    return min(words / 60, 1)


def evaluate_answer(question: str, answer: str, concepts: list = None) -> dict:
    answer = (answer or "").strip()
    answer_lower = answer.lower()
    concepts = concepts or CONCEPTS_BY_QUESTION.get(question, [])

    if len(answer.split()) < 3:
        return {
            "overall_score": 0.0,
            "technical_score": 0.0, "conceptual_score": 0.0,
            "explanation_score": 0.0, "completeness_score": 0.0,
            "feedback": {"strengths": [], "improvements": ["Write a real answer (at least a couple of sentences)."],
                         "covered_concepts": [], "missing_concepts": concepts, "confidence": "normal"},
        }

    tech_ratio, hit, miss, confidence = _technical(answer_lower, concepts)
    scores = {
        "technical": tech_ratio,
        "conceptual": _conceptual(answer_lower),
        "explanation": _explanation(answer, answer_lower),
        "completeness": _completeness(answer),
    }
    # Each dimension reported on a 0-100 scale for display.
    dims = {k: round(v * 100, 2) for k, v in scores.items()}
    overall = round(sum(scores[k] * w for k, w in WEIGHTS.items()), 2)

    strengths, improvements = [], []
    if hit:
        strengths.append(f"Covered key concepts: {', '.join(hit)}")
    if miss:
        improvements.append(f"Consider mentioning: {', '.join(miss)}")
    if scores["conceptual"] >= 0.5:
        strengths.append("You explained reasoning, not just terms")
    else:
        improvements.append("Explain *why* (use 'because', 'which means') rather than only naming things")
    if scores["explanation"] < 0.6:
        improvements.append("Structure the answer in a few clear sentences and add a concrete example")
    if scores["completeness"] < 0.5:
        improvements.append("Answer is quite short — add more depth")
    if confidence == "low":
        improvements.append("No reference concepts exist for this question, so the technical score is only an estimate")

    return {
        "overall_score": overall,
        "technical_score": dims["technical"],
        "conceptual_score": dims["conceptual"],
        "explanation_score": dims["explanation"],
        "completeness_score": dims["completeness"],
        "feedback": {"strengths": strengths, "improvements": improvements,
                     "covered_concepts": hit, "missing_concepts": miss, "confidence": confidence},
    }
