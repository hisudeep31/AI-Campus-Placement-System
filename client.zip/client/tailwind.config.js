/** @type {import(\"tailwindcss\").Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#1B2430",
        brandSlate: "#4C5B68",
        mist: "#EEF2F6",
        accent: "#2F6F5E",
        accentDark: "#234F42",
        warn: "#B4530A",
        danger: "#B3261E",
      },
      fontFamily: {
        display: ["\"Fraunces\"", "serif"],
        body: ["\"Inter\"", "sans-serif"],
      },
    },
  },
  plugins: [],
};
