import axios from "axios";

const api = axios.create({ baseURL: "/api" });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

const forceLogout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("refreshToken");
  localStorage.removeItem("user");
  window.location.href = "/login";
};

// V3: access tokens are short-lived (1h). On a 401 we try ONE silent refresh
// using the stored refresh token, then replay the failed request. Concurrent
// 401s share a single in-flight refresh so the rotating refresh token isn't
// spent twice. If refresh fails, the session is genuinely over -> login.
let refreshing = null;
const refreshAccessToken = () => {
  if (!refreshing) {
    const refreshToken = localStorage.getItem("refreshToken");
    if (!refreshToken) return Promise.reject(new Error("no refresh token"));
    refreshing = axios
      .post("/api/auth/refresh", { refreshToken })
      .then(({ data }) => {
        localStorage.setItem("token", data.token);
        localStorage.setItem("refreshToken", data.refreshToken);
        return data.token;
      })
      .finally(() => { refreshing = null; });
  }
  return refreshing;
};

api.interceptors.response.use(
  (res) => res,
  async (err) => {
    const original = err.config;
    const isAuthCall = original?.url?.startsWith("/auth/");
    if (err.response?.status === 401 && original && !original._retried && !isAuthCall) {
      original._retried = true;
      try {
        const token = await refreshAccessToken();
        original.headers.Authorization = `Bearer ${token}`;
        return api(original);
      } catch {
        forceLogout();
      }
    } else if (err.response?.status === 401 && !isAuthCall) {
      forceLogout();
    }
    return Promise.reject(err);
  }
);

export default api;
