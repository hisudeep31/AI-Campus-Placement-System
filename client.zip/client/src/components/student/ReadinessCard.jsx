import { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import api from "../../api/axios.js";

const BAND = {
  strong: ["Strong", "bg-green-100 text-green-700"],
  developing: ["Developing", "bg-amber-100 text-amber-700"],
  needs_attention: ["Needs attention", "bg-red-100 text-red-700"],
};
const LABELS = { cgpa: "CGPA", skills: "Skills", resume: "Resume (ATS)", projects: "Projects", mock_interviews: "Mock interviews", profile_extras: "Certificates & experience" };

export default function ReadinessCard() {
  const [data, setData] = useState(null);

  useEffect(() => { api.get("/students/me/readiness").then(({ data }) => setData(data)).catch(() => {}); }, []);
  if (!data) return null;

  const [bandLabel, bandClass] = BAND[data.band];
  const history = data.history.map((h) => ({ date: String(h.created_at).slice(5, 10), score: Number(h.readiness_score) }));

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold">Placement readiness</h3>
        <span className={`badge ${bandClass}`}>{bandLabel}</span>
      </div>
      <p className="text-4xl font-display font-semibold text-accent">{data.readiness}<span className="text-base text-slate"> / 100</span></p>
      <div className="grid gap-2 mt-4">
        {data.factors.map((f) => (
          <div key={f.key} className="flex items-center gap-3 text-sm">
            <span className="w-44 text-slate">{LABELS[f.key]}</span>
            <div className="flex-1 bg-slate/10 rounded h-2"><div className="bg-accent h-2 rounded" style={{ width: `${(f.score / f.max) * 100}%` }} /></div>
            <span className="w-14 text-right">{f.score}/{f.max}</span>
          </div>
        ))}
      </div>
      {data.suggestions.length > 0 && (
        <ul className="mt-4 text-sm list-disc list-inside text-slate">
          {data.suggestions.map((s) => <li key={s}>{s}</li>)}
        </ul>
      )}
      {history.length > 1 && (
        <div className="mt-4">
          <ResponsiveContainer width="100%" height={110}>
            <LineChart data={history}><XAxis dataKey="date" tick={{ fontSize: 10 }} /><YAxis domain={[0, 100]} hide /><Tooltip /><Line dataKey="score" stroke="#2F6F5E" strokeWidth={2} dot /></LineChart>
          </ResponsiveContainer>
        </div>
      )}
      <p className="text-[11px] text-slate mt-3">A transparent formula over your own profile — guidance for you, not a hiring decision or a prediction of outcomes.</p>
    </div>
  );
}
