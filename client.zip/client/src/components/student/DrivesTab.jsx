import { useEffect, useState } from "react";
import api from "../../api/axios.js";
import { useToast } from "../shared/Toast.jsx";
import EmptyState from "../shared/EmptyState.jsx";
import { CardSkeleton } from "../shared/Skeleton.jsx";

export default function DrivesTab() {
  const [drives, setDrives] = useState([]);
  const [msg, setMsg] = useState({});
  const [loading, setLoading] = useState(true);
  const toast = useToast();

  const load = async () => {
    const { data } = await api.get("/drives");
    setDrives(data);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const register = async (id) => {
    try {
      await api.post(`/drives/${id}/register`);
      toast.success("You're registered for the drive");
      setMsg((m) => ({ ...m, [id]: { ok: true, text: "Registered!" } }));
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || "Could not register");
      setMsg((m) => ({ ...m, [id]: { ok: false, text: err.response?.data?.error || "Could not register" } }));
    }
  };

  if (loading) return <CardSkeleton />;
  if (!drives.length) return <EmptyState title="No placement drives yet" hint="When your placement cell schedules a drive you'll see it here and get a notification." />;

  return (
    <div className="grid gap-3">
      {drives.map((d) => (
        <div key={d.id} className="card">
          <div className="flex justify-between gap-3 flex-wrap">
            <div>
              <h4 className="font-semibold">{d.title}</h4>
              <p className="text-sm text-slate">
                {d.drive_date ? `Drive date: ${String(d.drive_date).slice(0, 10)}` : "Date to be announced"}
                {d.registration_deadline && ` · Register by ${String(d.registration_deadline).slice(0, 10)}`}
              </p>
              {d.description && <p className="text-sm mt-2">{d.description}</p>}
              <p className="text-xs text-slate mt-2">
                {d.min_cgpa ? `Min CGPA ${d.min_cgpa}` : "No CGPA cutoff"}
                {d.eligible_departments?.length ? ` · ${d.eligible_departments.join(", ")}` : " · All departments"}
                {` · ${d.registered_count} registered`}
              </p>
            </div>
            <div className="text-right">
              <button className="btn-primary" onClick={() => register(d.id)}>Register</button>
              {msg[d.id] && <p className={`text-xs mt-2 ${msg[d.id].ok ? "text-accentDark" : "text-danger"}`}>{msg[d.id].text}</p>}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
