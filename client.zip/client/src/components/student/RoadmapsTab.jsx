import { useEffect, useState } from "react";
import api from "../../api/axios.js";
import { useToast } from "../shared/Toast.jsx";

export default function RoadmapsTab({ jobs }) {
  const [roadmaps, setRoadmaps] = useState([]);
  const [open, setOpen] = useState(null);
  const [detail, setDetail] = useState(null);
  const [jobId, setJobId] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const toast = useToast();

  const load = async () => {
    const { data } = await api.get("/roadmaps/me");
    setRoadmaps(data);
  };
  useEffect(() => { load(); }, []);

  const openRoadmap = async (id) => {
    setOpen(id);
    const { data } = await api.get(`/roadmaps/${id}`);
    setDetail(data);
  };

  const generate = async () => {
    if (!jobId) return;
    setBusy(true);
    setError("");
    try {
      const { data } = await api.post("/roadmaps/generate", { job_id: jobId });
      if (data.steps?.length === 0 && data.message) setError(data.message);
      else { await load(); openRoadmap(data.id); toast.success("Roadmap created"); }
    } catch (err) {
      setError(err.response?.data?.error || "Could not generate a roadmap");
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (idx, completed) => {
    await api.patch(`/roadmaps/${detail.id}/steps/${idx}`, { completed });
    openRoadmap(detail.id);
    load();
  };

  const steps = detail ? (typeof detail.steps === "string" ? JSON.parse(detail.steps) : detail.steps) : [];
  const done = new Set((detail?.progress || []).filter((p) => p.completed).map((p) => p.step_index));

  return (
    <div className="grid gap-4">
      <div className="card">
        <h3 className="font-semibold mb-2">Build a learning roadmap</h3>
        <p className="text-sm text-slate mb-3">Pick a job and we'll turn your missing skills into an ordered checklist (mandatory skills first).</p>
        <div className="flex gap-2 flex-wrap">
          <select className="input-field sm:max-w-sm" value={jobId} onChange={(e) => setJobId(e.target.value)}>
            <option value="">Select a target job</option>
            {jobs.map((j) => <option key={j.id} value={j.id}>{j.title} — {j.company_name}</option>)}
          </select>
          <button className="btn-primary" disabled={!jobId || busy} onClick={generate}>{busy ? "Building..." : "Generate roadmap"}</button>
        </div>
        {error && <p className="text-sm text-warn mt-2">{error}</p>}
      </div>

      {roadmaps.length > 0 && (
        <div className="card">
          <h3 className="font-semibold mb-3">Your roadmaps</h3>
          <div className="grid gap-2">
            {roadmaps.map((r) => (
              <button key={r.id} onClick={() => openRoadmap(r.id)}
                className={`text-left rounded-lg border p-3 text-sm ${open === r.id ? "border-accent" : "border-slate/10"}`}>
                {jobs.find((j) => j.id === r.job_id)?.title || "Custom roadmap"}
                <span className="text-slate"> · {r.completed_steps}/{r.total_steps} steps done</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {detail && (
        <div className="card">
          <h3 className="font-semibold mb-3">Steps</h3>
          <ol className="grid gap-3">
            {steps.map((s, i) => (
              <li key={i} className="flex gap-3 items-start">
                <input type="checkbox" className="mt-1" checked={done.has(i)} onChange={(e) => toggle(i, e.target.checked)} />
                <div className="text-sm">
                  <p className={`font-medium ${done.has(i) ? "line-through text-slate" : ""}`}>
                    {s.step}. {s.skill}
                    {s.priority === "high" && <span className="badge ml-2 bg-warn/10 text-warn">required</span>}
                  </p>
                  <p className="text-slate">{s.action} · ~{s.estimated_effort}</p>
                  {s.resource && (
                    <a className="text-accent" href={s.resource.url} target="_blank" rel="noreferrer">
                      {s.resource.title}{!s.resource.curated && " (search)"}
                    </a>
                  )}
                </div>
              </li>
            ))}
          </ol>
        </div>
      )}
    </div>
  );
}
