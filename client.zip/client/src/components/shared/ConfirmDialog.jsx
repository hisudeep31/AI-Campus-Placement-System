import { createContext, useCallback, useContext, useRef, useState } from "react";

const ConfirmContext = createContext(null);

// Promise-based confirm: `if (!(await confirm({ title, message }))) return;`
export function ConfirmProvider({ children }) {
  const [state, setState] = useState(null);
  const resolver = useRef(null);

  const confirm = useCallback((opts) => new Promise((resolve) => {
    resolver.current = resolve;
    setState(opts);
  }), []);

  const close = (result) => {
    resolver.current?.(result);
    setState(null);
  };

  return (
    <ConfirmContext.Provider value={confirm}>
      {children}
      {state && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => close(false)}>
          <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-sm" role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-semibold">{state.title || "Are you sure?"}</h3>
            {state.message && <p className="text-sm text-slate mt-2">{state.message}</p>}
            <div className="flex justify-end gap-2 mt-5">
              <button className="btn-secondary" onClick={() => close(false)}>Cancel</button>
              <button className={state.danger ? "btn-primary !bg-danger" : "btn-primary"} autoFocus onClick={() => close(true)}>
                {state.confirmLabel || "Confirm"}
              </button>
            </div>
          </div>
        </div>
      )}
    </ConfirmContext.Provider>
  );
}

export const useConfirm = () => {
  const ctx = useContext(ConfirmContext);
  // Fallback keeps behaviour safe (native confirm) outside the provider.
  return ctx || (async ({ message, title }) => window.confirm(message || title || "Are you sure?"));
};
