export function Skeleton({ className = "h-4 w-full" }) {
  return <div className={`animate-pulse rounded bg-slate/10 ${className}`} aria-hidden="true" />;
}

export function CardSkeleton({ rows = 3 }) {
  return (
    <div className="card grid gap-3" role="status" aria-label="Loading">
      <Skeleton className="h-5 w-1/3" />
      {Array.from({ length: rows }).map((_, i) => <Skeleton key={i} className="h-4 w-full" />)}
    </div>
  );
}
