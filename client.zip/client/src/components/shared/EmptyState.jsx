export default function EmptyState({ title, hint, action }) {
  return (
    <div className="card text-center py-10">
      <p className="font-medium">{title}</p>
      {hint && <p className="text-sm text-slate mt-1 max-w-md mx-auto">{hint}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
