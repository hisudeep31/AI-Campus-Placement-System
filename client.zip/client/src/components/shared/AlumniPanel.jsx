import { useEffect, useState } from "react";
import api from "../../api/axios.js";
import { useToast } from "./Toast.jsx";
import { useConfirm } from "./ConfirmDialog.jsx";
import EmptyState from "./EmptyState.jsx";

const EMPTY = { full_name: "", graduation_year: "", department: "", current_organization: "", job_role: "", industry: "", contact_email: "", linkedin_url: "", mentorship_available: false };

// Read-only for students; officers/admins (canEdit) can add and remove entries.
export default function AlumniPanel({ canEdit = false }) {
  const [rows, setRows] = useState([]);
  const [mentorOnly, setMentorOnly] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState("");
  const toast = useToast();
  const confirm = useConfirm();

  const load = async () => {
    const { data } = await api.get("/alumni", { params: mentorOnly ? { mentorship_only: true } : {} });
    setRows(data);
  };
  useEffect(() => { load(); }, [mentorOnly]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const add = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await api.post("/alumni", { ...form, graduation_year: form.graduation_year ? Number(form.graduation_year) : undefined });
      setForm(EMPTY);
      toast.success("Alumni added");
      load();
    } catch (err) {
      setError(err.response?.data?.error || "Could not add alumni");
    }
  };

  const remove = async (id) => {
    if (!(await confirm({ title: "Remove alumni record?", message: "This cannot be undone.", confirmLabel: "Remove", danger: true }))) return;
    await api.delete(`/alumni/${id}`);
    toast.success("Record removed");
    load();
  };

  return (
    <div className="grid gap-4">
      {canEdit && (
        <form onSubmit={add} className="card grid gap-3">
          <h3 className="font-semibold">Add alumni</h3>
          <div className="grid sm:grid-cols-3 gap-3">
            <input className="input-field" required placeholder="Full name" value={form.full_name} onChange={(e) => set("full_name", e.target.value)} />
            <input className="input-field" placeholder="Graduation year" value={form.graduation_year} onChange={(e) => set("graduation_year", e.target.value)} />
            <input className="input-field" placeholder="Department" value={form.department} onChange={(e) => set("department", e.target.value)} />
            <input className="input-field" placeholder="Current organization" value={form.current_organization} onChange={(e) => set("current_organization", e.target.value)} />
            <input className="input-field" placeholder="Job role" value={form.job_role} onChange={(e) => set("job_role", e.target.value)} />
            <input className="input-field" placeholder="Industry" value={form.industry} onChange={(e) => set("industry", e.target.value)} />
            <input className="input-field" placeholder="Contact email" value={form.contact_email} onChange={(e) => set("contact_email", e.target.value)} />
            <input className="input-field" placeholder="LinkedIn URL" value={form.linkedin_url} onChange={(e) => set("linkedin_url", e.target.value)} />
            <label className="text-sm flex items-center gap-2">
              <input type="checkbox" checked={form.mentorship_available} onChange={(e) => set("mentorship_available", e.target.checked)} />
              Open to mentoring
            </label>
          </div>
          <div className="flex items-center gap-3">
            <button className="btn-primary">Add alumni</button>
            {error && <span className="text-danger text-sm">{error}</span>}
          </div>
        </form>
      )}

      <div className="card">
        <div className="flex justify-between items-center mb-3 flex-wrap gap-2">
          <h3 className="font-semibold">Alumni directory</h3>
          <label className="text-sm flex items-center gap-2">
            <input type="checkbox" checked={mentorOnly} onChange={(e) => setMentorOnly(e.target.checked)} />
            Mentors only
          </label>
        </div>
        {!rows.length && <EmptyState title="No alumni records yet" hint={canEdit ? "Add graduates above so students can find mentors." : "Your placement cell hasn't added alumni yet."} />}
        <div className="grid sm:grid-cols-2 gap-3">
          {rows.map((a) => (
            <div key={a.id} className="rounded-lg border border-slate/10 p-3 text-sm">
              <p className="font-semibold">{a.full_name}
                {a.mentorship_available && <span className="badge ml-2 bg-accent/10 text-accentDark">Mentor</span>}
              </p>
              <p className="text-slate">{[a.job_role, a.current_organization].filter(Boolean).join(" @ ") || "—"}</p>
              <p className="text-slate text-xs">{[a.department, a.graduation_year && `Class of ${a.graduation_year}`, a.industry].filter(Boolean).join(" · ")}</p>
              <div className="flex gap-3 mt-2 text-xs">
                {a.contact_email && <a className="text-accent" href={`mailto:${a.contact_email}`}>Email</a>}
                {a.linkedin_url && <a className="text-accent" href={a.linkedin_url} target="_blank" rel="noreferrer">LinkedIn</a>}
                {canEdit && <button className="text-danger ml-auto" onClick={() => remove(a.id)}>Remove</button>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
