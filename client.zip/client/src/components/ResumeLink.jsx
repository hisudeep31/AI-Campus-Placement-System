import { useState } from "react";
import api from "../api/axios.js";

// V3: resumes are no longer publicly served. This fetches the file through
// the authenticated /api/resumes/:id/download endpoint (token attached by
// the axios instance) and opens it from a temporary blob URL.
export default function ResumeLink({ resumeId, children = "View resume", className = "text-sm text-accent font-medium" }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const open = async () => {
    setBusy(true);
    setError("");
    try {
      const res = await api.get(`/resumes/${resumeId}/download`, { responseType: "blob" });
      const url = URL.createObjectURL(res.data);
      window.open(url, "_blank", "noopener");
      setTimeout(() => URL.revokeObjectURL(url), 60_000);
    } catch (err) {
      setError(err.response?.status === 403 ? "No permission" : "Could not open resume");
    } finally {
      setBusy(false);
    }
  };

  if (!resumeId) return null;
  return (
    <span>
      <button type="button" className={className} onClick={open} disabled={busy}>
        {busy ? "Opening..." : children}
      </button>
      {error && <span className="text-danger text-xs ml-2">{error}</span>}
    </span>
  );
}
