import { useEffect, useState } from "react";
import api from "../../api/axios.js";

const FUNNEL_ORDER = ["applied", "under_review", "shortlisted", "interview_scheduled", "interview_completed", "selected", "rejected", "on_hold"];

export default function InsightsTab() {
  const [stats, setStats] = useState(null);
  const [docs, setDocs] = useState({ verification_status: "pending", documents: [] });
  const [docType, setDocType] = useState("registration_certificate");
  const [file, setFile] = useState(null);
  const [error, setError] = useState("");

  const load = async () => {
    const [a, d] = await Promise.all([api.get("/companies/analytics"), api.get("/companies/me/documents")]);
    setStats(a.data);
    setDocs(d.data);
  };
  useEffect(() => { load(); }, []);

  const upload = async (e) => {
    e.preventDefault();
    if (!file) return;
    setError("");
    const fd = new FormData();
    fd.append("document", file);
    fd.append("doc_type", docType);
    try {
      await api.post("/companies/me/documents", fd);
      setFile(null);
      e.target.reset();
      load();
    } catch (err) {
      setError(err.response?.data?.error || "Upload failed");
    }
  };

  const badge = { verified: "bg-green-100 text-green-700", pending: "bg-amber-100 text-amber-700", rejected: "bg-red-100 text-red-700" };
  const max = stats ? Math.max(1, ...Object.values(stats.funnel)) : 1;

  return (
    <div className="grid gap-4">
      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold">Company verification</h3>
          <span className={`badge capitalize ${badge[docs.verification_status]}`}>{docs.verification_status}</span>
        </div>
        <p className="text-sm text-slate mb-3">Upload a registration certificate or similar proof. A placement officer reviews it; verified companies get a badge on their jobs.</p>
        <form onSubmit={upload} className="flex gap-2 flex-wrap items-center">
          <select className="input-field w-auto" value={docType} onChange={(e) => setDocType(e.target.value)}>
            <option value="registration_certificate">Registration certificate</option>
            <option value="gst">GST / tax document</option>
            <option value="authorization_letter">Authorization letter</option>
            <option value="other">Other</option>
          </select>
          <input type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={(e) => setFile(e.target.files[0])} />
          <button className="btn-secondary" disabled={!file}>Upload</button>
        </form>
        {error && <p className="text-danger text-sm mt-2">{error}</p>}
        {docs.documents.length > 0 && (
          <ul className="mt-3 text-sm text-slate list-disc list-inside">
            {docs.documents.map((d) => <li key={d.id}>{d.doc_type} — {String(d.uploaded_at).slice(0, 10)}</li>)}
          </ul>
        )}
      </div>

      {stats && (
        <>
          <div className="grid sm:grid-cols-3 gap-3">
            <div className="card"><p className="text-sm text-slate">Applications</p><p className="text-3xl font-display font-semibold">{stats.total_applications}</p></div>
            <div className="card"><p className="text-sm text-slate">Selection rate</p><p className="text-3xl font-display font-semibold text-accent">{stats.selection_rate}%</p></div>
            <div className="card"><p className="text-sm text-slate">Avg interview score</p>
              <p className="text-3xl font-display font-semibold">{stats.interviews?.avg_interview_score ?? "—"}<span className="text-sm text-slate"> /10</span></p></div>
          </div>

          <div className="card">
            <h3 className="font-semibold mb-3">Hiring funnel</h3>
            {stats.total_applications === 0 && <p className="text-sm text-slate">No applications yet.</p>}
            <div className="grid gap-2">
              {FUNNEL_ORDER.filter((s) => stats.funnel[s]).map((s) => (
                <div key={s} className="flex items-center gap-3 text-sm">
                  <span className="w-40 capitalize text-slate">{s.replace(/_/g, " ")}</span>
                  <div className="flex-1 bg-slate/10 rounded h-3"><div className="bg-accent h-3 rounded" style={{ width: `${(stats.funnel[s] / max) * 100}%` }} /></div>
                  <span className="w-8 text-right">{stats.funnel[s]}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="card overflow-x-auto">
            <h3 className="font-semibold mb-3">Per-job performance</h3>
            <table className="w-full text-sm">
              <thead><tr className="text-left text-slate"><th className="py-1">Job</th><th>Applicants</th><th>Shortlisted</th><th>Selected</th><th>Avg match</th></tr></thead>
              <tbody>
                {stats.per_job.map((j) => (
                  <tr key={j.id} className="border-t border-slate/10">
                    <td className="py-2">{j.title}</td><td>{j.applicants}</td><td>{j.shortlisted}</td><td>{j.selected}</td><td>{j.avg_match_score ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
