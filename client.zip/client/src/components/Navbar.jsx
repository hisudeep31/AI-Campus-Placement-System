import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import NotificationBell from "./NotificationBell.jsx";

const roleHome = {
  student: "/student",
  company: "/company",
  placement_officer: "/officer",
  admin: "/admin",
};

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="border-b border-slate-200 bg-white">
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link to={user ? roleHome[user.role] : "/"} className="text-xl font-display font-semibold text-ink">
          Placement<span className="text-accent">Hub</span>
        </Link>
        <nav className="flex items-center gap-4 text-sm">
          {!user && (
            <>
              <Link to="/jobs" className="text-slate hover:text-ink">Browse Jobs</Link>
              <Link to="/login" className="text-slate hover:text-ink">Log in</Link>
              <Link to="/register" className="btn-primary text-sm">Sign up</Link>
            </>
          )}
          {user && (
            <>
              <Link to={roleHome[user.role] || "/"} className="text-slate hover:text-ink">Dashboard</Link>
              <span className="text-slate hidden sm:inline">{user.email}</span>
              <span className="badge bg-accent/10 text-accentDark capitalize">{user.role.replace("_", " ")}</span>
              <NotificationBell />
              <button
                onClick={() => { logout(); navigate("/login"); }}
                className="btn-secondary text-sm"
              >
                Log out
              </button>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
