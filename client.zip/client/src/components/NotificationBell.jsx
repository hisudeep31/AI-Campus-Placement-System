import { useEffect, useRef, useState } from "react";
import api from "../api/axios.js";

export default function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const containerRef = useRef(null);

  const loadUnreadCount = async () => {
    try {
      const { data } = await api.get("/notifications/me/unread-count");
      setUnreadCount(data.count);
    } catch {
      // silently ignore — notification polling shouldn't surface errors to the user
    }
  };

  const loadNotifications = async () => {
    try {
      const { data } = await api.get("/notifications/me");
      setNotifications(data);
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    loadUnreadCount();
    const interval = setInterval(loadUnreadCount, 20000); // poll every 20s
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const toggleOpen = async () => {
    const next = !open;
    setOpen(next);
    if (next) await loadNotifications();
  };

  const markAllRead = async () => {
    await api.patch("/notifications/read-all");
    setUnreadCount(0);
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
  };

  const markOneRead = async (id) => {
    await api.patch(`/notifications/${id}/read`);
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)));
    loadUnreadCount();
  };

  return (
    <div className="relative" ref={containerRef}>
      <button
        onClick={toggleOpen}
        className="relative w-9 h-9 flex items-center justify-center rounded-lg hover:bg-mist transition-colors"
        aria-label="Notifications"
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
          <path d="M13.73 21a2 2 0 01-3.46 0" />
        </svg>
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 bg-danger text-white text-[10px] font-semibold rounded-full w-4 h-4 flex items-center justify-center">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-80 max-h-96 overflow-y-auto bg-white border border-slate-200 rounded-xl shadow-lg z-50">
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
            <p className="font-semibold text-sm">Notifications</p>
            {notifications.some((n) => !n.is_read) && (
              <button onClick={markAllRead} className="text-xs text-accent font-medium">Mark all read</button>
            )}
          </div>
          <div className="divide-y divide-slate-100">
            {notifications.map((n) => (
              <button
                key={n.id}
                onClick={() => !n.is_read && markOneRead(n.id)}
                className={`w-full text-left px-4 py-3 text-sm hover:bg-mist transition-colors ${!n.is_read ? "bg-accent/5" : ""}`}
              >
                <p className="font-medium">{n.title}</p>
                <p className="text-slate text-xs mt-0.5">{n.message}</p>
                <p className="text-slate text-xs mt-1 opacity-60">{new Date(n.created_at).toLocaleString()}</p>
              </button>
            ))}
            {!notifications.length && (
              <p className="text-slate text-sm px-4 py-6 text-center">No notifications yet.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
