export default function StatCard({ label, value, accent }) {
  return (
    <div className="card">
      <p className="text-sm text-slate">{label}</p>
      <p className={`text-3xl font-display font-semibold mt-1 ${accent ? "text-accent" : "text-ink"}`}>
        {value}
      </p>
    </div>
  );
}
