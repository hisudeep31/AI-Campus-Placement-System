import { useEffect, useState } from "react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, LineChart, Line, XAxis, YAxis, BarChart, Bar, Legend } from "recharts";
import api from "../../api/axios.js";

const COLORS = ["#2F6F5E", "#4F8FBF", "#E0A84B", "#B65C5C", "#7A6FB5", "#8A9AA6", "#5BAA8F", "#C98A5B"];
const fmt = (n) => (n == null ? "—" : Number(n).toLocaleString());

async function downloadPdf() {
  const res = await api.get("/officer/reports/pdf", { responseType: "blob" });
  const url = URL.createObjectURL(new Blob([res.data], { type: "application/pdf" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = "placement_summary.pdf";
  a.click();
  URL.revokeObjectURL(url);
}

export default function InstitutionalInsights() {
  const [salary, setSalary] = useState(null);
  const [yearly, setYearly] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [readiness, setReadiness] = useState(null);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [pdfError, setPdfError] = useState("");

  useEffect(() => {
    api.get("/officer/analytics/salary").then(({ data }) => setSalary(data));
    api.get("/officer/analytics/yearly").then(({ data }) => setYearly(data));
    api.get("/officer/analytics/status-distribution").then(({ data }) => setStatuses(data));
    api.get("/officer/analytics/readiness").then(({ data }) => setReadiness(data));
  }, []);

  const exportPdf = async () => {
    setPdfBusy(true);
    setPdfError("");
    try { await downloadPdf(); }
    catch { setPdfError("PDF export failed (is pdfkit installed on the server?)"); }
    finally { setPdfBusy(false); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Institutional insights</h3>
        <div className="text-right">
          <button className="btn-secondary text-xs" onClick={exportPdf} disabled={pdfBusy}>{pdfBusy ? "Building PDF..." : "Download PDF summary"}</button>
          {pdfError && <p className="text-danger text-xs mt-1">{pdfError}</p>}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="card">
          <h4 className="font-semibold mb-3">Application status mix</h4>
          {statuses.length ? (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={statuses} dataKey="value" nameKey="name" outerRadius={85} label={(e) => e.name.replace(/_/g, " ")}>
                  {statuses.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : <p className="text-sm text-slate">No applications yet.</p>}
        </div>

        <div className="card">
          <h4 className="font-semibold mb-3">Placement % by graduation year</h4>
          {yearly.length ? (
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={yearly}>
                <XAxis dataKey="year" tick={{ fontSize: 12 }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} unit="%" />
                <Tooltip />
                <Line type="monotone" dataKey="placement_percentage" stroke="#2F6F5E" strokeWidth={2} name="Placement %" />
              </LineChart>
            </ResponsiveContainer>
          ) : <p className="text-sm text-slate">No graduation-year data yet.</p>}
        </div>
      </div>

      {salary && (
        <div className="card">
          <h4 className="font-semibold mb-3">Salary analytics</h4>
          {salary.summary.offers_with_salary === 0 ? (
            <p className="text-sm text-slate">No offers with a recorded salary yet. Companies can enter a salary when marking a candidate as selected.</p>
          ) : (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center mb-4">
                {[["Average", salary.summary.average], ["Median", salary.summary.median], ["Highest", salary.summary.highest], ["Lowest", salary.summary.lowest]].map(([l, v]) => (
                  <div key={l}><p className="text-lg font-semibold">{fmt(v)}</p><p className="text-xs text-slate">{l}</p></div>
                ))}
              </div>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={salary.by_department.map((d) => ({ ...d, department: d.department || "Unassigned" }))}>
                  <XAxis dataKey="department" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="average" fill="#4F8FBF" name="Average package" />
                </BarChart>
              </ResponsiveContainer>
            </>
          )}
        </div>
      )}

      {readiness && (
        <div className="card">
          <div className="flex items-baseline justify-between mb-3 flex-wrap gap-2">
            <h4 className="font-semibold">Placement readiness</h4>
            <p className="text-sm text-slate">Cohort average <span className="font-semibold text-ink">{readiness.average_readiness}</span>/100 · rule-based, not a prediction</p>
          </div>
          <div className="grid grid-cols-3 gap-3 text-center mb-4">
            {[["strong", "Strong"], ["developing", "Developing"], ["needs_attention", "Needs attention"]].map(([k, l]) => (
              <div key={k} className="rounded-lg bg-slate/5 p-3"><p className="text-2xl font-semibold">{readiness.distribution[k]}</p><p className="text-xs text-slate">{l}</p></div>
            ))}
          </div>
          {readiness.needs_attention.length > 0 && (
            <div className="overflow-x-auto">
              <p className="text-sm font-medium mb-2">Unplaced students who may need support</p>
              <table className="w-full text-sm">
                <thead><tr className="text-left text-slate"><th className="py-1">Student</th><th>Dept</th><th>Score</th><th>Biggest gap</th></tr></thead>
                <tbody>
                  {readiness.needs_attention.map((s) => (
                    <tr key={s.id} className="border-t border-slate/10"><td className="py-2">{s.full_name}</td><td>{s.department || "—"}</td><td>{s.readiness}</td><td className="text-slate">{s.top_gap || "—"}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
