import { useEffect, useState } from "react";
import api from "../../api/axios.js";
import { useToast } from "../shared/Toast.jsx";

export default function DrivesManageTab() {
  const [drives, setDrives] = useState([]);
  const [form, setForm] = useState({ title: "", description: "", drive_date: "", registration_deadline: "", min_cgpa: "", eligible_departments: "" });
  const [error, setError] = useState("");
  const [selected, setSelected] = useState(null);
  const [attendance, setAttendance] = useState([]);
  const toast = useToast();

  const load = async () => {
    const { data } = await api.get("/drives");
    setDrives(data);
  };
  useEffect(() => { load(); }, []);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const create = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await api.post("/drives", {
        title: form.title,
        description: form.description || undefined,
        drive_date: form.drive_date || undefined,
        registration_deadline: form.registration_deadline || undefined,
        min_cgpa: form.min_cgpa ? Number(form.min_cgpa) : undefined,
        eligible_departments: form.eligible_departments ? form.eligible_departments.split(",").map((s) => s.trim()).filter(Boolean) : [],
      });
      setForm({ title: "", description: "", drive_date: "", registration_deadline: "", min_cgpa: "", eligible_departments: "" });
      toast.success("Drive created and students notified");
      load();
    } catch (err) {
      setError(err.response?.data?.error || "Could not create drive");
    }
  };

  const openAttendance = async (id) => {
    setSelected(id);
    const { data } = await api.get(`/drives/${id}/attendance`);
    setAttendance(data);
  };

  const mark = async (registrationId, attended, outcome) => {
    await api.patch(`/drives/attendance/${registrationId}`, { attended, outcome });
    openAttendance(selected);
  };

  return (
    <div className="grid gap-4">
      <form onSubmit={create} className="card grid gap-3">
        <h3 className="font-semibold">Create placement drive</h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <input className="input-field" required placeholder="Title" value={form.title} onChange={(e) => set("title", e.target.value)} />
          <input className="input-field" placeholder="Min CGPA (optional)" value={form.min_cgpa} onChange={(e) => set("min_cgpa", e.target.value)} />
          <label className="text-sm">Drive date<input type="date" className="input-field" value={form.drive_date} onChange={(e) => set("drive_date", e.target.value)} /></label>
          <label className="text-sm">Registration deadline<input type="date" className="input-field" value={form.registration_deadline} onChange={(e) => set("registration_deadline", e.target.value)} /></label>
          <input className="input-field sm:col-span-2" placeholder="Eligible departments, comma separated (blank = all)" value={form.eligible_departments} onChange={(e) => set("eligible_departments", e.target.value)} />
          <textarea className="input-field sm:col-span-2" rows={2} placeholder="Description" value={form.description} onChange={(e) => set("description", e.target.value)} />
        </div>
        <div className="flex items-center gap-3">
          <button className="btn-primary">Create drive</button>
          {error && <span className="text-danger text-sm">{error}</span>}
        </div>
      </form>

      <div className="card">
        <h3 className="font-semibold mb-3">Drives</h3>
        {!drives.length && <p className="text-sm text-slate">No drives yet.</p>}
        <div className="grid gap-2">
          {drives.map((d) => (
            <div key={d.id} className="flex justify-between items-center border border-slate/10 rounded-lg p-3 text-sm">
              <div>
                <p className="font-medium">{d.title}</p>
                <p className="text-slate text-xs">{d.drive_date ? String(d.drive_date).slice(0, 10) : "No date"} · {d.registered_count} registered</p>
              </div>
              <button className="btn-secondary" onClick={() => openAttendance(d.id)}>Attendance</button>
            </div>
          ))}
        </div>
      </div>

      {selected && (
        <div className="card">
          <h3 className="font-semibold mb-3">Attendance &amp; outcomes</h3>
          {!attendance.length && <p className="text-sm text-slate">No registrations yet.</p>}
          <div className="grid gap-2">
            {attendance.map((r) => (
              <div key={r.registration_id} className="flex justify-between items-center gap-3 flex-wrap text-sm border-b border-slate/10 pb-2">
                <span>{r.full_name} <span className="text-slate text-xs">{r.department}</span></span>
                <div className="flex gap-2 items-center">
                  <label className="flex items-center gap-1">
                    <input type="checkbox" checked={!!r.attended} onChange={(e) => mark(r.registration_id, e.target.checked, r.outcome)} />
                    Attended
                  </label>
                  <select className="input-field w-auto" value={r.outcome || ""} onChange={(e) => mark(r.registration_id, r.attended ?? true, e.target.value || null)}>
                    <option value="">Outcome...</option>
                    <option value="shortlisted">Shortlisted</option>
                    <option value="selected">Selected</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
