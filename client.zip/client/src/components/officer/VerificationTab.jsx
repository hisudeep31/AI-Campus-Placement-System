import { useEffect, useState } from "react";
import api from "../../api/axios.js";
import { useToast } from "../shared/Toast.jsx";

const openDoc = async (id) => {
  const res = await api.get(`/verification/documents/${id}/download`, { responseType: "blob" });
  const url = URL.createObjectURL(res.data);
  window.open(url, "_blank", "noopener");
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
};

export default function VerificationTab() {
  const [status, setStatus] = useState("pending");
  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");
  const toast = useToast();

  const load = async () => {
    const { data } = await api.get("/officer/verification", { params: { status } });
    setRows(data);
  };
  useEffect(() => { load(); }, [status]);

  const decide = async (id, next) => {
    let reason;
    if (next === "rejected") {
      reason = window.prompt("Reason for rejection (shown to the company):");
      if (reason === null) return;
    }
    setError("");
    try {
      await api.patch(`/officer/verification/${id}`, { status: next, reason });
      toast.success(next === "verified" ? "Company verified" : "Company rejected");
      load();
    } catch (err) {
      setError(err.response?.data?.error || "Could not update verification");
    }
  };

  return (
    <div>
      <div className="flex gap-2 mb-4">
        {["pending", "verified", "rejected"].map((s) => (
          <button key={s} onClick={() => setStatus(s)}
            className={`px-3 py-1.5 rounded-full text-sm capitalize ${status === s ? "bg-accent text-white" : "bg-slate/10"}`}>{s}</button>
        ))}
      </div>
      {error && <p className="text-danger text-sm mb-3">{error}</p>}
      {!rows.length && <div className="card text-sm text-slate">No {status} companies.</div>}
      <div className="grid gap-3">
        {rows.map((c) => (
          <div key={c.id} className="card">
            <div className="flex justify-between gap-3 flex-wrap">
              <div>
                <h4 className="font-semibold">{c.company_name}</h4>
                <p className="text-sm text-slate">{c.email}{c.industry && ` · ${c.industry}`}{c.website && ` · ${c.website}`}</p>
                <div className="flex gap-3 mt-2 flex-wrap text-sm">
                  {c.documents.length === 0 && <span className="text-warn">No documents uploaded</span>}
                  {c.documents.map((d) => (
                    <button key={d.id} className="text-accent" onClick={() => openDoc(d.id)}>{d.doc_type}</button>
                  ))}
                </div>
              </div>
              <div className="flex gap-2 items-start">
                {status !== "verified" && <button className="btn-primary" onClick={() => decide(c.id, "verified")}>Verify</button>}
                {status !== "rejected" && <button className="btn-secondary" onClick={() => decide(c.id, "rejected")}>Reject</button>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
