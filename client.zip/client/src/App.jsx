import { Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext.jsx";
import Navbar from "./components/Navbar.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

import Home from "./pages/Home.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import JobsBrowse from "./pages/JobsBrowse.jsx";
import StudentDashboard from "./pages/StudentDashboard.jsx";
import CompanyDashboard from "./pages/CompanyDashboard.jsx";
import OfficerDashboard from "./pages/OfficerDashboard.jsx";
import AdminDashboard from "./pages/AdminDashboard.jsx";

export default function App() {
  return (
    <AuthProvider>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/jobs" element={<JobsBrowse />} />
        <Route path="/student" element={
          <ProtectedRoute allowedRoles={["student"]}><StudentDashboard /></ProtectedRoute>
        } />
        <Route path="/company" element={
          <ProtectedRoute allowedRoles={["company"]}><CompanyDashboard /></ProtectedRoute>
        } />
        <Route path="/officer" element={
          <ProtectedRoute allowedRoles={["placement_officer"]}><OfficerDashboard /></ProtectedRoute>
        } />
        <Route path="/admin" element={
          <ProtectedRoute allowedRoles={["admin"]}><AdminDashboard /></ProtectedRoute>
        } />
      </Routes>
    </AuthProvider>
  );
}
